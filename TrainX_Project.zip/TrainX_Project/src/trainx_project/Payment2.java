/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/GUIForms/JFrame.java to edit this template
 */
package trainx_project;
import java.awt.event.FocusEvent;
import java.awt.event.FocusListener;
import java.io.File;
import java.io.FileNotFoundException;
import java.lang.System.*;
import java.math.BigDecimal;
import java.nio.charset.StandardCharsets;
import java.time.*;
import java.util.*;
import java.util.logging.Logger;
import java.util.logging.Level;
import javax.swing.JOptionPane;
import trainx_project.ConfirmYourTripDetails.*;
import trainx_project.TravelDetails.*;
/**
 *this.bookingNo = bookingNo;
    this.trainRoute = trainRoute;
    this.selectedSeats = selectedSeats;
    this.totalPrice = totalPrice;
    this.travelDate = travelDate;
    this.fromCity = fromCity;
    this.toCity = toCity;
    this.returnDate = returnDate;
 * @author renad
 */

public class Payment2 extends javax.swing.JFrame {

    private static final String DEFAULT_CARD_NUMBER_TEXT = "XXXX-XXXX-XXXX-XXXX";
    private static final String DEFAULT_CVC_TEXT = "XXX";
    private static final String DEFAULT_CARD_HOLDER_TEXT = "ENTER CARD HOLDER NAME";
    private static double totalAmount;
    private static String bookingNumber;
    private java.sql.Date bookingDate;
    private int numOfPass;
    private String passId;
    
    private List<String> classType;
    private List<Double> classPrice;
    private  List<String> seatsNum;
    
    private int trainId;
    private Date travelDate;//java.sql.Date
    private BigDecimal amount;
    
    private Date paymentDate;//
    private java.sql.Time paymentTime;
    
     public static TravelDetails tdFrame;
     public static ConfirmYourTripDetails c;
     
     DBConnectionAndQueries con=new DBConnectionAndQueries();
     public static CardPayment cardPayment;
     public static String bookingNo;
    public static int totalPrice;
    public static Set<String> selectedSeats;
    public static Payment1 p;
     
     public Payment2(trainx_project.Payment cardPayment, TravelDetails tdFrame, Payment1 p) {
        initComponents();
        PrintBill.setVisible(false);
        this.cardPayment=(CardPayment) cardPayment;
        this.tdFrame=tdFrame;
        this.selectedSeats = tdFrame.selectedSeats;
        this.passId = tdFrame.passId;
        this.classType = tdFrame.classOfSeats;
        this.seatsNum = tdFrame.choosenSeats;
        this.trainId = tdFrame.goTrainId;
        this.travelDate = tdFrame.travelDate;
        this.amount = tdFrame.totalFee;
        this.classPrice=classPrice;
        
        this.p=p;
        // -- imtinan
        classPrice = new ArrayList<>();
        for (String seat : selectedSeats) {
             if (c.isFirstClass(seat)) {
                classPrice.add(250.0);
            } else {
                classPrice.add(150.0);
            }
        addFocusListeners();
        setInitialDate();
        }
    
     }
     
     private void processPayment() {
        String cardNumber = jTextField1.getText().trim();
        String cvc = jTextField3.getText().trim();
        String cardHolderName = jTextField4.getText().trim();

        String cleanCardNumber = cardNumber.replace("-", "").replace(" ", "");

        // Validate Card Number
        if (cardNumber.isEmpty() || cardNumber.equals(DEFAULT_CARD_NUMBER_TEXT) || cleanCardNumber.length() != 16 || !cleanCardNumber.matches("\\d+")) {
            JOptionPane.showMessageDialog(this,
                    "Please enter a valid 16-digit card number.",
                    "Input Error",
                    JOptionPane.WARNING_MESSAGE);
            return;
        }

        // Validate CVV
        if (cvc.isEmpty() || cvc.equals(DEFAULT_CVC_TEXT) || (cvc.length() != 3) || !cvc.matches("\\d+")) {
            JOptionPane.showMessageDialog(this,
                    "Please enter a valid 3-digit CVC.",
                    "Input Error",
                    JOptionPane.WARNING_MESSAGE);
            return;
        }

        // Validate Card Holder Name
        if (cardHolderName.isEmpty() || cardHolderName.equals(DEFAULT_CARD_HOLDER_TEXT)) {
            JOptionPane.showMessageDialog(this,
                    "Please enter the card holder's name.",
                    "Input Error",
                    JOptionPane.WARNING_MESSAGE);
            return;
        }

        // Validate Expiration Date
        int selectedYear = yearChooser.getYear();
        int selectedMonth = monthChooser.getMonth() + 1; // JMonthChooser is 0-indexed
        YearMonth selectedYearMonth = YearMonth.of(selectedYear, selectedMonth);
        YearMonth currentYearMonth = YearMonth.now();

        if (selectedYearMonth.isBefore(currentYearMonth)) {
            JOptionPane.showMessageDialog(this, "Expiration date cannot be in the past.", "Input Error", JOptionPane.ERROR_MESSAGE);
            setInitialDate();
            return;
        }

        try {
            CardPayment payment = new CardPayment(
                    cardNumber,
                    cvc,
                    cardHolderName,
                    String.valueOf(selectedMonth),
                    String.valueOf(selectedYear)
            );

            // Insert booking, tickets, and payment into the database
            int result = con.insertBknTknP(
                    passId,
                    classType,
                    classPrice,
                    seatsNum,
                    trainId,
                    new java.sql.Date(travelDate.getTime()),
                    amount
            );

            if (result > 0) {
                JOptionPane.showMessageDialog(this, "Payment successful!", "Success", JOptionPane.INFORMATION_MESSAGE);
                PrintBill.setVisible(true); // Enable Print Bill button after successful payment
            } else {
                JOptionPane.showMessageDialog(this, "Failed to process payment. Please try again.", "Error", JOptionPane.ERROR_MESSAGE);
            }

        } catch (Exception e) {
            JOptionPane.showMessageDialog(this,
                    "An unexpected error occurred during payment: " + e.getMessage(),
                    "Payment Error",
                    JOptionPane.ERROR_MESSAGE);
            e.printStackTrace();
        }
    }
     
     // -- imtinan
    private void setInitialDate() {
        YearMonth currentYearMonth = YearMonth.now();
        int currentYear = currentYearMonth.getYear();
        int currentMonth = currentYearMonth.getMonthValue() - 1; // JMonthChooser is 0-indexed

        yearChooser.setYear(currentYear);
        monthChooser.setMonth(currentMonth);
    }

    /**
     * This method is called from within the constructor to initialize the form.
     * WARNING: Do NOT modify this code. The content of this method is always
     * regenerated by the Form Editor.
     */
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jPanel2 = new javax.swing.JPanel();
        jLabel2 = new javax.swing.JLabel();
        jLabel3 = new javax.swing.JLabel();
        jTextField1 = new javax.swing.JTextField();
        jTextField3 = new javax.swing.JTextField();
        jTextField4 = new javax.swing.JTextField();
        jLabel8 = new javax.swing.JLabel();
        jLabel9 = new javax.swing.JLabel();
        jButton3 = new javax.swing.JButton();
        jButton4 = new javax.swing.JButton();
        jButton5 = new javax.swing.JButton();
        jLabel4 = new javax.swing.JLabel();
        monthChooser = new com.toedter.calendar.JMonthChooser();
        yearChooser = new com.toedter.calendar.JYearChooser();
        PrintBill = new javax.swing.JButton();
        jPanel3 = new javax.swing.JPanel();
        jLabel6 = new javax.swing.JLabel();
        jLabel7 = new javax.swing.JLabel();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);

        jPanel2.setBackground(new java.awt.Color(225, 225, 225));
        jPanel2.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        jLabel2.setFont(new java.awt.Font("Times New Roman", 1, 12)); // NOI18N
        jLabel2.setText("CARD NUMBER");
        jPanel2.add(jLabel2, new org.netbeans.lib.awtextra.AbsoluteConstraints(75, 218, -1, -1));

        jLabel3.setFont(new java.awt.Font("Times New Roman", 1, 14)); // NOI18N
        jLabel3.setText("CVV");
        jPanel2.add(jLabel3, new org.netbeans.lib.awtextra.AbsoluteConstraints(345, 216, -1, -1));

        jTextField1.setBackground(new java.awt.Color(225, 225, 225));
        jTextField1.setFont(new java.awt.Font("Courier New", 0, 10)); // NOI18N
        jTextField1.setHorizontalAlignment(javax.swing.JTextField.CENTER);
        jTextField1.setText("XXXX-XXXX-XXXX-XXXX");
        jTextField1.setBorder(javax.swing.BorderFactory.createMatteBorder(0, 0, 1, 0, new java.awt.Color(0, 0, 0)));
        jTextField1.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jTextField1ActionPerformed(evt);
            }
        });
        jPanel2.add(jTextField1, new org.netbeans.lib.awtextra.AbsoluteConstraints(184, 214, 106, 25));

        jTextField3.setBackground(new java.awt.Color(225, 225, 225));
        jTextField3.setFont(new java.awt.Font("Courier New", 0, 10)); // NOI18N
        jTextField3.setHorizontalAlignment(javax.swing.JTextField.CENTER);
        jTextField3.setText("XXX");
        jTextField3.setBorder(javax.swing.BorderFactory.createMatteBorder(0, 0, 1, 0, new java.awt.Color(0, 0, 0)));
        jTextField3.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jTextField3ActionPerformed(evt);
            }
        });
        jPanel2.add(jTextField3, new org.netbeans.lib.awtextra.AbsoluteConstraints(393, 214, 30, 25));

        jTextField4.setBackground(new java.awt.Color(225, 225, 225));
        jTextField4.setFont(new java.awt.Font("Courier New", 1, 10)); // NOI18N
        jTextField4.setHorizontalAlignment(javax.swing.JTextField.CENTER);
        jTextField4.setText("ENTER CARD HOLDER NAME");
        jTextField4.setBorder(javax.swing.BorderFactory.createMatteBorder(0, 0, 1, 0, new java.awt.Color(0, 0, 0)));
        jTextField4.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jTextField4ActionPerformed(evt);
            }
        });
        jPanel2.add(jTextField4, new org.netbeans.lib.awtextra.AbsoluteConstraints(222, 263, -1, 25));

        jLabel8.setFont(new java.awt.Font("Times New Roman", 1, 12)); // NOI18N
        jLabel8.setText("CARD HOLDER NAME");
        jPanel2.add(jLabel8, new org.netbeans.lib.awtextra.AbsoluteConstraints(75, 267, -1, -1));

        jLabel9.setFont(new java.awt.Font("Times New Roman", 1, 12)); // NOI18N
        jLabel9.setText("EXPIRATION DATE");
        jPanel2.add(jLabel9, new org.netbeans.lib.awtextra.AbsoluteConstraints(75, 321, -1, -1));

        jButton3.setBackground(new java.awt.Color(51, 51, 51));
        jButton3.setFont(new java.awt.Font("Times New Roman", 1, 18)); // NOI18N
        jButton3.setForeground(new java.awt.Color(204, 204, 204));
        jButton3.setText("Pay");
        jButton3.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton3ActionPerformed(evt);
            }
        });
        jPanel2.add(jButton3, new org.netbeans.lib.awtextra.AbsoluteConstraints(250, 360, 127, 41));

        jButton4.setFont(new java.awt.Font("Times New Roman", 1, 14)); // NOI18N
        jButton4.setText("Next");
        jButton4.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton4ActionPerformed(evt);
            }
        });
        jPanel2.add(jButton4, new org.netbeans.lib.awtextra.AbsoluteConstraints(400, 380, 106, -1));

        jButton5.setFont(new java.awt.Font("Times New Roman", 1, 14)); // NOI18N
        jButton5.setText("Back");
        jButton5.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton5ActionPerformed(evt);
            }
        });
        jPanel2.add(jButton5, new org.netbeans.lib.awtextra.AbsoluteConstraints(110, 380, 106, -1));

        jLabel4.setIcon(new javax.swing.ImageIcon("C:\\Users\\emten\\Pictures\\renad pics\\IMG-20250502-WA0037.jpg")); // NOI18N
        jLabel4.setText("Card image 169x244");
        jPanel2.add(jLabel4, new org.netbeans.lib.awtextra.AbsoluteConstraints(184, 18, 244, -1));

        monthChooser.setFont(new java.awt.Font("Times New Roman", 0, 12)); // NOI18N
        jPanel2.add(monthChooser, new org.netbeans.lib.awtextra.AbsoluteConstraints(222, 314, 125, -1));

        yearChooser.addPropertyChangeListener(new java.beans.PropertyChangeListener() {
            public void propertyChange(java.beans.PropertyChangeEvent evt) {
                yearChooserPropertyChange(evt);
            }
        });
        jPanel2.add(yearChooser, new org.netbeans.lib.awtextra.AbsoluteConstraints(365, 314, -1, -1));

        PrintBill.setFont(new java.awt.Font("Times New Roman", 1, 14)); // NOI18N
        PrintBill.setText("Print Bill");
        PrintBill.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                PrintBillActionPerformed(evt);
            }
        });
        jPanel2.add(PrintBill, new org.netbeans.lib.awtextra.AbsoluteConstraints(260, 420, 106, -1));

        jPanel3.setBackground(new java.awt.Color(255, 255, 255));

        jLabel6.setFont(new java.awt.Font("Times New Roman", 1, 24)); // NOI18N
        jLabel6.setText("TrainX");

        jLabel7.setIcon(new javax.swing.ImageIcon(getClass().getResource("/trainx_project/logoResized.jpg"))); // NOI18N
        jLabel7.setText("Logo 184x149");

        javax.swing.GroupLayout jPanel3Layout = new javax.swing.GroupLayout(jPanel3);
        jPanel3.setLayout(jPanel3Layout);
        jPanel3Layout.setHorizontalGroup(
            jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel3Layout.createSequentialGroup()
                .addGroup(jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel3Layout.createSequentialGroup()
                        .addGap(25, 25, 25)
                        .addComponent(jLabel7, javax.swing.GroupLayout.PREFERRED_SIZE, 149, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addGroup(jPanel3Layout.createSequentialGroup()
                        .addGap(66, 66, 66)
                        .addComponent(jLabel6)))
                .addContainerGap(32, Short.MAX_VALUE))
        );
        jPanel3Layout.setVerticalGroup(
            jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel3Layout.createSequentialGroup()
                .addGap(95, 95, 95)
                .addComponent(jLabel7, javax.swing.GroupLayout.PREFERRED_SIZE, 184, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(18, 18, 18)
                .addComponent(jLabel6)
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addComponent(jPanel3, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(jPanel2, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jPanel2, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
            .addComponent(jPanel3, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void jTextField3ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jTextField3ActionPerformed
        jTextField3.setText(DEFAULT_CVC_TEXT);
    }//GEN-LAST:event_jTextField3ActionPerformed

    private void jTextField1ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jTextField1ActionPerformed
        jTextField1.setText(DEFAULT_CARD_NUMBER_TEXT);
    }//GEN-LAST:event_jTextField1ActionPerformed

    private void jTextField4ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jTextField4ActionPerformed
        jTextField4.setText(DEFAULT_CARD_HOLDER_TEXT);
    }//GEN-LAST:event_jTextField4ActionPerformed

    private void jButton3ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton3ActionPerformed
       // -- imtinan
        processPayment();
             if (tdFrame.returnTrainId < 0 && tdFrame.returnDate== null)  {
                 con.insertBknTknP(passId, classType, classPrice, seatsNum, trainId, new java.sql.Date(travelDate.getTime()), amount);
             }
             else{
                 con.insertBknTknP(passId, classType, classPrice, seatsNum, trainId, new java.sql.Date(travelDate.getTime()), amount,tdFrame.returnTrainId,new java.sql.Date(tdFrame.returnDate.getTime()));
             }
        

    }//GEN-LAST:event_jButton3ActionPerformed

    private void jButton4ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton4ActionPerformed
        // TODO add your handling code here:
        this.dispose();
        PassMainPage h = new PassMainPage(passId);
        h.setVisible(true);
        h.setLocationRelativeTo(this);
        h.setSize(800,500);
        h.setResizable(false);
    }//GEN-LAST:event_jButton4ActionPerformed

    private void jButton5ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton5ActionPerformed
            
        p.setVisible(true);
        p.setSize(800,500);
        p.setResizable(false);
        p.setLocationRelativeTo(this);

        this.setVisible(false);
    }//GEN-LAST:event_jButton5ActionPerformed

    private void yearChooserPropertyChange(java.beans.PropertyChangeEvent evt) {//GEN-FIRST:event_yearChooserPropertyChange
        // TODO add your handling code here:
        
    
    }//GEN-LAST:event_yearChooserPropertyChange

    private void PrintBillActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_PrintBillActionPerformed
        // TODO add your handling code here:
        generateInvoice();
    }//GEN-LAST:event_PrintBillActionPerformed


    // -- bayan
        
    private void generateInvoice() {
        if (selectedSeats == null || selectedSeats.isEmpty()) {
            JOptionPane.showMessageDialog(this, "No seats selected. Please go back and select seats.", "Error", JOptionPane.ERROR_MESSAGE);
            return;
        }

        Random rand = new Random();
        int invoiceNo = 1000000 + rand.nextInt(9000000);
        
        String desktopPath = System.getProperty("user.home") + File.separator + "Desktop" + File.separator + "TrainX_Invoice_" + invoiceNo + ".txt";
        
        File desktopDir = new File(System.getProperty("user.home") + File.separator + "Desktop");
        if (!desktopDir.exists()) {
            desktopDir.mkdirs();
        }

        Formatter output = null;
        try {
            output = new Formatter(new File(desktopPath), StandardCharsets.UTF_8.name());
            
            output.format("TrainX%n");
            output.format("Train Route: %s%n", ConfirmYourTripDetails.trainRouteField.getText());
            output.format("------------------------%n");
            
            output.format("Seat Number%10sPrice%n", "");
            for (String seat : selectedSeats) {
                output.format("%-10s$ %s%n", seat, ConfirmYourTripDetails.isFirstClass(seat) ? "250" : "150");
            }
            output.format("------------------------%n");
            output.format("Total%14s$ %s%n", "", ConfirmYourTripDetails.totalPriceField.getText());
            
            output.format("Travel Date:%9s%s%n", "", ConfirmYourTripDetails.travelDateField.getText());
            output.format("From city:%11s%s%n", "", ConfirmYourTripDetails.fromCityField.getText());
            output.format("To city:%13s%s%n", "", ConfirmYourTripDetails.toCityField.getText());
            if (!ConfirmYourTripDetails.returnDateField.getText().isEmpty()) {
                output.format("Return Date:%7s%s%n", "", ConfirmYourTripDetails.returnDateField.getText());
            }
            
            output.format("Thank you%n");
            
            JOptionPane.showMessageDialog(this, "Invoice saved successfully on Desktop as TrainX_Invoice_" + invoiceNo + ".txt");

        } catch (SecurityException securityException) {
            JOptionPane.showMessageDialog(this, "Write permission denied. Unable to save invoice.", "Error", JOptionPane.ERROR_MESSAGE);
        } catch (FormatterClosedException formatterClosedException) {
            JOptionPane.showMessageDialog(this, "Error writing to file. Unable to save invoice.", "Error", JOptionPane.ERROR_MESSAGE);
        } catch (FileNotFoundException ex) {
            JOptionPane.showMessageDialog(this, "Unable to create file on Desktop. Please check your permissions or Desktop path.", "Error", JOptionPane.ERROR_MESSAGE);
            Logger.getLogger(Payment2.class.getName()).log(Level.SEVERE, null, ex);
        } catch (Exception ex) {
            JOptionPane.showMessageDialog(this, "An unexpected error occurred while saving the invoice: " + ex.getMessage(), "Error", JOptionPane.ERROR_MESSAGE);
            Logger.getLogger(Payment2.class.getName()).log(Level.SEVERE, null, ex);
        } finally {
            if (output != null) {
                output.close();
            }
        }
    }
   

    
    
    // New method to add focus listeners to text fields
    private void addFocusListeners() {
        // Focus Listener for Card Number
        jTextField1.addFocusListener(new FocusListener() {
            @Override
            public void focusGained(FocusEvent e) {
                if (jTextField1.getText().equals(DEFAULT_CARD_NUMBER_TEXT)) {
                    jTextField1.setText("");
                }
            }

            @Override
            public void focusLost(FocusEvent e) {
                if (jTextField1.getText().isEmpty()) {
                    jTextField1.setText(DEFAULT_CARD_NUMBER_TEXT);
                }
            }
        });

        // Focus Listener for CVC
        jTextField3.addFocusListener(new FocusListener() {
            @Override
            public void focusGained(FocusEvent e) {
                if (jTextField3.getText().equals(DEFAULT_CVC_TEXT)) {
                    jTextField3.setText("");
                }
            }

            @Override
            public void focusLost(FocusEvent e) {
                if (jTextField3.getText().isEmpty()) {
                    jTextField3.setText(DEFAULT_CVC_TEXT);
                }
            }
        });

        // Focus Listener for Card Holder Name
        jTextField4.addFocusListener(new FocusListener() {
            @Override
            public void focusGained(FocusEvent e) {
                if (jTextField4.getText().equals(DEFAULT_CARD_HOLDER_TEXT)) {
                    jTextField4.setText("");
                }
            }

            @Override
            public void focusLost(FocusEvent e) {
                if (jTextField4.getText().isEmpty()) {
                    jTextField4.setText(DEFAULT_CARD_HOLDER_TEXT);
                }
            }
        });
    }
    
    /**
     * @param args the command line arguments
     * if (selectedMonth == null || selectedMonth.isEmpty()) {
         javax.swing.JOptionPane.showMessageDialog(this,
                "Please select an expiration month.",
                "Input Error",
                javax.swing.JOptionPane.WARNING_MESSAGE);
        return;
    }
    
    if (selectedYear == null || selectedYear.isEmpty()) {
         javax.swing.JOptionPane.showMessageDialog(this,
                "Please select an expiration year.",
                "Input Error",
                javax.swing.JOptionPane.WARNING_MESSAGE);
        return;
    }
     */
    public static void main(String args[]) {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(Payment2.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(Payment2.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(Payment2.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(Payment2.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>
        //</editor-fold>

        /* Create and display the form */
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new Payment2(cardPayment,tdFrame,p).setVisible(true);
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton PrintBill;
    private javax.swing.JButton jButton3;
    private javax.swing.JButton jButton4;
    private javax.swing.JButton jButton5;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JLabel jLabel3;
    private javax.swing.JLabel jLabel4;
    private javax.swing.JLabel jLabel6;
    private javax.swing.JLabel jLabel7;
    private javax.swing.JLabel jLabel8;
    private javax.swing.JLabel jLabel9;
    private javax.swing.JPanel jPanel2;
    private javax.swing.JPanel jPanel3;
    private javax.swing.JTextField jTextField1;
    private javax.swing.JTextField jTextField3;
    private javax.swing.JTextField jTextField4;
    private com.toedter.calendar.JMonthChooser monthChooser;
    private com.toedter.calendar.JYearChooser yearChooser;
    // End of variables declaration//GEN-END:variables
}
