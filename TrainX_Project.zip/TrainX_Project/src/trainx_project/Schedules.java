/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package trainx_project;

import java.util.Date;

/**
 *
 * @author Zahra Redha
 */
public class Schedules {
     private int Schedule_id ;
    private Date Departure;
    private Date Arrival;
    private String Trip_Total_Time;
    private String Route_From;
    private String Route_To;
    private int Route_Distance;
    private int Train_Id;

    public Schedules(int Schedule_id, Date Departure, Date Arrival, String Trip_Total_Time, String Route_From, String Route_To, int Route_Distance,int Train_Id) {
        this.Schedule_id = Schedule_id;
        this.Departure = Departure;
        this.Arrival = Arrival;
        this.Trip_Total_Time = Trip_Total_Time;
        this.Route_From = Route_From;
        this.Route_To = Route_To;
        this.Route_Distance = Route_Distance;
        this.Train_Id= Train_Id;
    }

    //Info Tickets
    public Schedules(Date Departure, String Trip_Total_Time, String Route_From, String Route_To,int  Train_Id) {
        this.Departure = Departure;
        this.Trip_Total_Time = Trip_Total_Time;
        this.Route_From = Route_From;
        this.Route_To = Route_To;
        this.Train_Id= Train_Id;
    }

    @Override
    public String toString() {
        return "Schedules{" + "Schedule_id=" + Schedule_id + ", Departure=" + Departure + ", Arrival=" + Arrival + ", Trip_Total_Time=" + Trip_Total_Time + ", Route_From=" + Route_From + ", Route_To=" + Route_To + ", Route_Distance=" + Route_Distance + ", Train_Id=" + Train_Id + '}';
    }

    public int getTrain_Id() {
        return Train_Id;
    }

    public void setTrain_Id(int Train_Id) {
        this.Train_Id = Train_Id;
    }
    
    
    /**
     * @return the Schedule_id
     */
    public int getSchedule_id() {
        return Schedule_id;
    }

    /**
     * @param Schedule_id the Schedule_id to set
     */
    public void setSchedule_id(int Schedule_id) {
        this.Schedule_id = Schedule_id;
    }

    /**
     * @return the Departure
     */
    public Date getDeparture() {
        return Departure;
    }

    /**
     * @param Departure the Departure to set
     */
    public void setDeparture(Date Departure) {
        this.Departure = Departure;
    }

    /**
     * @return the Arrival
     */
    public Date getArrival() {
        return Arrival;
    }

    /**
     * @param Arrival the Arrival to set
     */
    public void setArrival(Date Arrival) {
        this.Arrival = Arrival;
    }

    /**
     * @return the Trip_Total_Time
     */
    public String getTrip_Total_Time() {
        return Trip_Total_Time;
    }

    /**
     * @param Trip_Total_Time the Trip_Total_Time to set
     */
    public void setTrip_Total_Time(String Trip_Total_Time) {
        this.Trip_Total_Time = Trip_Total_Time;
    }

    /**
     * @return the Route_From
     */
    public String getRoute_From() {
        return Route_From;
    }

    /**
     * @param Route_From the Route_From to set
     */
    public void setRoute_From(String Route_From) {
        this.Route_From = Route_From;
    }

    /**
     * @return the Route_To
     */
    public String getRoute_To() {
        return Route_To;
    }

    /**
     * @param Route_To the Route_To to set
     */
    public void setRoute_To(String Route_To) {
        this.Route_To = Route_To;
    }

    /**
     * @return the Route_Distance
     */
    public int getRoute_Distance() {
        return Route_Distance;
    }

    /**
     * @param Route_Distance the Route_Distance to set
     */
    public void setRoute_Distance(int Route_Distance) {
        this.Route_Distance = Route_Distance;
    }
    
}
