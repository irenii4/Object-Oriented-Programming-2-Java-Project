/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package trainx_project;

import java.util.Date;

/**
 *
 * @author Zahra Redha
 */
public class Passenger {
    private String Passenger_Id;
    private String Passenger_Pass;
    private String First_Name;
    private String Last_Name;
    private Date PassengerDOB;

    public Passenger(String Passenger_Id, String Passenger_Pass, String First_Name, String Last_Name, Date PassengerDOB) {
        this.Passenger_Id = Passenger_Id;
        this.Passenger_Pass = Passenger_Pass;
        this.First_Name = First_Name;
        this.Last_Name = Last_Name;
        this.PassengerDOB = PassengerDOB;
    }

    /**
     * @return the Passenger_Id
     */
    public String getPassenger_Id() {
        return Passenger_Id;
    }

    /**
     * @param Passenger_Id the Passenger_Id to set
     */
    public void setPassenger_Id(String Passenger_Id) {
        this.Passenger_Id = Passenger_Id;
    }

    /**
     * @return the Passenger_Pass
     */
    public String getPassenger_Pass() {
        return Passenger_Pass;
    }

    /**
     * @param Passenger_Pass the Passenger_Pass to set
     */
    public void setPassenger_Pass(String Passenger_Pass) {
        this.Passenger_Pass = Passenger_Pass;
    }

    /**
     * @return the First_Name
     */
    public String getFirst_Name() {
        return First_Name;
    }

    /**
     * @param First_Name the First_Name to set
     */
    public void setFirst_Name(String First_Name) {
        this.First_Name = First_Name;
    }

    /**
     * @return the Last_Name
     */
    public String getLast_Name() {
        return Last_Name;
    }

    /**
     * @param Last_Name the Last_Name to set
     */
    public void setLast_Name(String Last_Name) {
        this.Last_Name = Last_Name;
    }

    /**
     * @return the PassengerDOB
     */
    public Date getPassengerDOB() {
        return PassengerDOB;
    }

    /**
     * @param PassengerDOB the PassengerDOB to set
     */
    public void setPassengerDOB(Date PassengerDOB) {
        this.PassengerDOB = PassengerDOB;
    }
    
    
    
    
}
