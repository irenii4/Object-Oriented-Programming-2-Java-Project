/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package trainx_project;
import java.sql.*;
import javax.swing.*;
import java.util.*;
/**
 *
 * @author emten
 */
public class TrainX_Project {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) throws SQLException, ClassNotFoundException {
        
        HomePage y = new HomePage();
        y.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        y.setVisible(true);
        y.setLocationRelativeTo(null);
        y.setSize(800, 500);
        y.setResizable(false);
        
        
        
        
        
    }
}