/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package trainx_project;

/**
 *
 * @author renad
 */
public class Staff {
    private String managerId;
    private String phoneNumber;
    private String firstName;
    private String lastName;
    private String email;
    private String birthDate;
    private double salary;
    private String managerPassword;

    // Constructor
    public Staff(String managerId, String phoneNumber, String firstName, String lastName, String email, String birthDate, double salary) {
        this.phoneNumber = phoneNumber;
        this.firstName = firstName;
        this.lastName = lastName;
        this.email = email;
        this.birthDate = birthDate;
        this.salary = salary;
    }

    // Getters
    public String getManagerId() {
        return managerId;
    }

    public String getPhoneNumber() {
        return phoneNumber;
    }

    public String getFirstName() {
        return firstName;
    }

    public String getLastName() {
        return lastName;
    }

    public String getEmail() {
        return email;
    }

    public String getBirthDate() {
        return birthDate;
    }

    public double getSalary() {
        return salary;
    }

    public String getManagerPassword() {
        return managerPassword;
    }

    // Setters
    public void setManagerId(String managerId) {
        this.managerId = managerId;
    }

    public void setPhoneNumber(String phoneNumber) {
        this.phoneNumber = phoneNumber;
    }

    public void setFirstName(String firstName) {
        this.firstName = firstName;
    }

    public void setLastName(String lastName) {
        this.lastName = lastName;
    }

    public void setEmail(String email) {
        this.email = email;
    }

    public void setBirthDate(String birthDate) {
        this.birthDate = birthDate;
    }

    public void setSalary(double salary) {
        this.salary = salary;
    }

    public void setManagerPassword(String managerPassword) {
        this.managerPassword = managerPassword;
    }

    @Override
    public String toString() {
        return "Staff{" +
                " firstName='" + firstName + '\n' +
                ", lastName='" + lastName + '\n' +
                ", email='" + email + '\n' +
                ", phoneNumber='" + phoneNumber + '\n' +
                ", birthDate='" + birthDate + '\n' +
                ", salary=" + salary +
                ", managerPassword='" + managerPassword + '\n' +
                '}';
    }
}