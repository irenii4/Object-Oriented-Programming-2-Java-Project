/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package trainx_project;

import java.sql.*;
import java.util.ArrayList;
import java.util.List;

import javax.swing.JTable;
import net.proteanit.sql.DbUtils;

/**
 *
 * @author Zahra Redha
 */
public class TrainXDBCon {
    static String URL = "jdbc:mysql://localhost:3306/TrainX_DB2"; 
    static  String USERNAME = "root"; 
    static String PASSWORD = "AA5011yy!";
    
    private Connection connection;
    private PreparedStatement getBookings;
    private PreparedStatement getTickets;
    private PreparedStatement getTrips;
    private PreparedStatement getSpecificTrip;
    
    private PreparedStatement deleteTickets;
    private PreparedStatement updatebookings;
    private PreparedStatement generateTickets;
    
    private PreparedStatement getSelectedSeats;
    
    public TrainXDBCon() 
    {       
        try{
           
            
        
           
    
            connection=DriverManager.getConnection(URL, USERNAME, PASSWORD);
            
            
            //return Bookings relevent with specific Passanger_Id
            getBookings=connection.prepareStatement("SELECT * FROM Booking WHERE Passenger_Id=?");
            //return tickets relevent with Booking_Number
            getTickets=connection.prepareStatement("SELECT * FROM Tickets WHERE Booking_Number = ?");
            //return Trips with specified destination and 
            getTrips=connection.prepareStatement("SELECT DISTINCT * FROM Schedules WHERE Route_From =? AND Route_To=? AND Departure=?;");
            
            //return one trip (route) based on trip id & travel date
            getSpecificTrip=connection.prepareStatement("SELECT Departure,Trip_Total_Time,Route_From,Route_To,Train_Id "
                    + "FROM Schedules "
                    + "WHERE Train_Id = ? && Departure = ?");
            
            
            
            
            deleteTickets=connection.prepareStatement("DELETE FROM Tickets WHERE Booking_Number = ?");
            updatebookings=connection.prepareStatement("UPDATE Booking SET Number_of_Passengers= ? , Booking_Date=curdate() "
                    + "WHERE Booking_Number=?");
            generateTickets=connection.prepareStatement(
                    "INSERT INTO Tickets ( Class_Type, Class_Price, Seat_Number, Booking_Number, Train_ID, Travel_date) "
                            + "VALUES (?, ?, ?, ?, ?, ?)");
            
            
            
            
            //to get the selected seats in a specific trip
            getSelectedSeats=connection.prepareStatement("SELECT Seat_Number FROM Tickets  WHERE Train_Id = ? && Travel_date = ?");
            
       }catch(SQLException sqlException){
           sqlException.printStackTrace();
           System.exit(1);
       }
        
        System.out.println("connection is sucssful");
      
    }//end of constructor
    
    public ArrayList<Booking> getBookings(String Passenger_Id)
        {
            ArrayList<Booking> result=null;
            ResultSet resultSet2=null;
            
            try{
                getBookings.setString(1, Passenger_Id);
                resultSet2=getBookings.executeQuery();
            
                result=new ArrayList<Booking>();
                
                while(resultSet2.next()){
                    result.add(new Booking (resultSet2.getString("Booking_Number"),
                            resultSet2.getDate("Booking_Date"),
                            resultSet2.getInt("Number_of_Passengers"),
                            resultSet2.getString("Passenger_Id")
                    ));}
                
               for(Booking b:result)
                    System.out.println(b);
                
            
            }catch(SQLException sqlException){
                System.out.print("\nSQLException in getBookings");
                sqlException.printStackTrace();
                System.exit(1);
            }finally{
                //System.out.print("\n\nfinally block");
                try{
                    resultSet2.close();
                }catch(SQLException sqlException){
                    sqlException.printStackTrace();
                    close();  
                }
            }
          
            return result;
        } //end of getBookings method, R: ArrayList<Booking>
    
    public ArrayList<Tickets> getTickets(String Booking_Number){
            ArrayList<Tickets> result=null;
            ResultSet resultSet=null;
            
            try{
                getTickets.setString(1, Booking_Number);
                resultSet=getTickets.executeQuery();
            
                result=new ArrayList<Tickets>();
                
                //needs modification
                //add Tkicket values from the DB
                while(resultSet.next()){
                    result.add(new Tickets(
                        resultSet.getString("Ticket_Id"),
                        resultSet.getString("Class_Type"),
                        resultSet.getDouble("Class_Price"),
                        resultSet.getString("Seat_Number"),
                        resultSet.getString("Booking_Number"),
                        resultSet.getInt("Train_Id"), 
                        resultSet.getDate("Travel_date")
                    ));}
                
               for(Tickets t:result)
                    System.out.println(t);
                
            }catch(SQLException sqlException){
                System.out.print("\nSQLException in getTickets");
                sqlException.printStackTrace();
                System.exit(1);
            }finally{
                //System.out.print("\n\nfinally block");
                try{
                    resultSet.close();
                }catch(SQLException sqlException){
                    sqlException.printStackTrace();
                    close(); 
                }
            }
          
            return result;
    }//end of getTickets method, R: ArrayList<Tickets>
    
    public ArrayList<Schedules> getTripsOneRoute(String from, String to,Date date){
            ArrayList<Schedules> result=null;
            ResultSet resultSet=null;
            
            try{
                getTrips.setString(1, from);
                getTrips.setString(2, to);
                getTrips.setDate(3, date);
                resultSet=getTrips.executeQuery();
            
                result=new ArrayList<Schedules>();
                
                //add Tkicket values from the DB
                while(resultSet.next()){
                    result.add(new Schedules(
                            resultSet.getInt("Schedule_id"),
                            resultSet.getDate("Departure"),
                            resultSet.getDate("Arrival"),
                            resultSet.getString("Trip_Total_Time"),
                            resultSet.getString("Route_From"),
                            resultSet.getString("Route_To"),
                            resultSet.getInt("Route_Distance"),
                            resultSet.getInt("Train_Id")
                    ));}
                
               for(Schedules s:result)
                    System.out.println(s);
                
            }catch(SQLException sqlException){
                System.out.print("\nSQLException in getTrips");
                sqlException.printStackTrace();
                System.exit(1);
            }finally{
                //System.out.print("\n\nfinally block");
                try{
                    resultSet.close();
                }catch(SQLException sqlException){
                    sqlException.printStackTrace();
                    close(); 
                }
            }
          
            return result;
    }//end of getTripsOneRoute method, R: ArrayList<Schedules>
    
    public Schedules getSpecificTrip(int TrainId, Date depature){
            Schedules result=null;
            ResultSet resultSet=null;
          
            try{
                getSpecificTrip.setInt(1, TrainId);
                getSpecificTrip.setDate(2, depature);
                resultSet=getSpecificTrip.executeQuery();
            
                if (resultSet.next()) {
                result = new Schedules(
                resultSet.getDate("Departure"),
                resultSet.getString("Trip_Total_Time"),
                resultSet.getString("Route_From"),
                resultSet.getString("Route_To"),
                resultSet.getInt("Train_Id")
            );
        }

        System.out.println("Schedule fetched: " + result);
                
            }catch(SQLException sqlException){
                System.out.print("\nSQLException in getSpecificTrips");
                sqlException.printStackTrace();
                System.exit(1);
            }finally{
                //System.out.print("\n\nfinally block");
                try{
                    resultSet.close();
                }catch(SQLException sqlException){
                    sqlException.printStackTrace();
                    close(); 
                }
            }
          
            return result;
    }//end of getSpecificTrip method, R: Schedules Object
    
    
  
   public void updateTable(JTable table,String Booking_Number){
       ResultSet resultSet=null;
       
       try{
            getTickets.setString(1, Booking_Number);
            resultSet=getTickets.executeQuery();
            table.setModel(DbUtils.resultSetToTableModel(resultSet));
            table.setEnabled(false);//only allowed to view the tickets
       }catch(SQLException sqlException){
                System.out.print("\nSQLException in getSpecificTrips");
                sqlException.printStackTrace();
                System.exit(1);
            }finally{
                //System.out.print("\n\nfinally block");
                try{
                    resultSet.close();
                }catch(SQLException sqlException){
                    sqlException.printStackTrace();
                    close(); 
                }
            }
   } // end of updateTable
   
   public int updateFoundTrips(JTable table,String from, String to,Date date){
       ResultSet resultSet=null;
       int tripFound=-1;
       
       try{
            getTrips.setString(1, from);
            getTrips.setString(2, to);
            getTrips.setDate(3, date);
            resultSet=getTrips.executeQuery();
            
            
            
            table.setModel(DbUtils.resultSetToTableModel(resultSet));
           if(resultSet.next()){
                tripFound=5;
                resultSet.absolute(-1);
            }
       }catch(SQLException sqlException){
                System.out.print("\nSQLException in updateFoundTrips");
                sqlException.printStackTrace();
                System.exit(1);
            }finally{
                //System.out.print("\n\nfinally block");
                try{
                    resultSet.close();
                }catch(SQLException sqlException){
                    sqlException.printStackTrace();
                    close(); 
                }
            }
       return tripFound;
   } // end of updateFoundTrips, R:int
    
   
   public int deleteOldTickets(String bookingNumber,ArrayList<String> seatsClass,ArrayList<String> seatsNum,
                                int trainId,Date travelDate, ArrayList<Double>ticketFee)
   {
       
       
       int ticketsDeleted=0;
       int updateBooking=0;
       int ticketsGenerated=0;
       
       int numOfPassangers=0;
       
          
            try{
                // 1. delete the old tickets
                deleteTickets.setString(1, bookingNumber);
                ticketsDeleted=deleteTickets.executeUpdate();
                
                // 2. update the booking table information
                numOfPassangers=seatsNum.size();
                updatebookings.setInt(1, numOfPassangers);
                updatebookings.setString(2, bookingNumber);
                updateBooking=updatebookings.executeUpdate();
                  
                // 3. generate new Tickets
                for (int i=0;i<numOfPassangers;i++){
                    //fill the values
                    generateTickets.setString(1, seatsClass.get(i));
                    generateTickets.setDouble(2, ticketFee.get(i));
                    generateTickets.setString(3, seatsNum.get(i));
                    generateTickets.setString(4, bookingNumber);
                    generateTickets.setInt(5, trainId);
                    generateTickets.setDate(6, travelDate);
                    
                    //Insert
                    ticketsGenerated=generateTickets.executeUpdate();
                }
                
            }catch(SQLException sqlException){
                System.out.print("\nSQLException in getSpecificTrips");
                sqlException.printStackTrace();
                close(); 
            }
            
            
            if(ticketsDeleted<0 || updateBooking<0 || ticketsGenerated<0){
                return -1;
            }
            else 
                return 1;
    }//end of deleteOldTickets method, R: int
   
   public int deleteOldTickets(String bookingNumber,ArrayList<String> seatsClass,ArrayList<String> seatsNum,
                                int trainId,Date travelDate, ArrayList<Double>ticketFee,int returnTrainId, Date returnDate)
   {
       
       
       int ticketsDeleted=0;
       int updateBooking=0;
       int ticketsGenerated=0;
       
       
       int numOfPassangers=0;
       
            
            
          
            try{
                // 1. delete the old tickets
                deleteTickets.setString(1, bookingNumber);
                ticketsDeleted=deleteTickets.executeUpdate();
                
                // 2. update the booking table information
                numOfPassangers=seatsNum.size();
                updatebookings.setInt(1, numOfPassangers);
                updatebookings.setString(2, bookingNumber);
                updateBooking=updatebookings.executeUpdate();
                  
                // 3. generate new Tickets
                //3.1 first Trip 
                for (int i=0;i<numOfPassangers;i++){
                    //fill the values
                    generateTickets.setString(1, seatsClass.get(i));
                    generateTickets.setDouble(2, ticketFee.get(i));
                    generateTickets.setString(3, seatsNum.get(i));
                    generateTickets.setString(4, bookingNumber);
                    generateTickets.setInt(5, trainId);
                    generateTickets.setDate(6, travelDate);
                    
                    //Insert
                    ticketsGenerated=generateTickets.executeUpdate();
                }
                
                //3.2 Return Trip Trip 
                for (int i=0;i<numOfPassangers;i++){
                    //fill the values
                    generateTickets.setString(1, seatsClass.get(i));
                    generateTickets.setDouble(2, ticketFee.get(i));
                    generateTickets.setString(3, seatsNum.get(i));
                    generateTickets.setString(4, bookingNumber);
                    generateTickets.setInt(5, returnTrainId);
                    generateTickets.setDate(6, returnDate);
                    
                    //Insert
                    ticketsGenerated=generateTickets.executeUpdate();
                }
                
            }catch(SQLException sqlException){
                System.out.print("\nSQLException in getSpecificTrips");
                sqlException.printStackTrace();
                close(); 
            }
            
            
            if(ticketsDeleted<0 || updateBooking<0 || ticketsGenerated<0){
                return -1;
            }
            else 
                return 1;
    }//end of deleteOldTickets method, R: int
   
   public List<String> getSelectedSeats(int traidId,Date travelDate)
   {
       ArrayList<String> result=null;
       ResultSet resultSet=null;
       
       try{
                getSelectedSeats.setInt(1, traidId);
                getSelectedSeats.setDate(2, travelDate);
                resultSet=getSelectedSeats.executeQuery();
            
                result=new ArrayList<String>();
                
                while(resultSet.next()){
                    result.add(
                          resultSet.getString("Seat_Number")
                    );
                }
                
               for(String b:result)
                    System.out.println(b);
                
            
            }catch(SQLException sqlException){
                System.out.print("\nSQLException in getSelectedSeats");
                sqlException.printStackTrace();
                System.exit(1);
            }finally{
                //System.out.print("\n\nfinally block");
                try{
                    resultSet.close();
                }catch(SQLException sqlException){
                    sqlException.printStackTrace();
                    close();  
                }
            }
       
       
       return result;
   }//end of getSelectedSeats method, R: List<String>
   
    //in case of exceptions
    public void close(){
        try{
            connection.close();
        }
        catch(SQLException e)
        {
            e.printStackTrace();
        }
    }
}
