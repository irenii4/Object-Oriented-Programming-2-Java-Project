package trainx_project;

/**
 *
 * @author shahad
 */
public class Train {
    private int trainId;
    private String driverName;
    private String model;
    private int maxDistance;
    private String status;
    private int capacity;
    private String managerId;

    // train class constructor
    public Train(int trainId, String driverName, int capacity,int maxDistance, String model,  String status, String managerId) {
        this.trainId = trainId;
        this.driverName = driverName;
        this.model = model;
        this.maxDistance = maxDistance;
        this.status = status;
        this.capacity = capacity;
        this.managerId = managerId;
    }
    
    
    // getters for the fields
    /**
     * @return the trainId
     */
    public int getTrainId() {
        return trainId;
    }

    /**
     * @return the driverName
     */
    public String getDriverName() {
        return driverName;
    }

    /**
     * @return the model
     */
    public String getModel() {
        return model;
    }

    /**
     * @return the maxDistance
     */
    public int getMaxDistance() {
        return maxDistance;
    }

    /**
     * @return the status
     */
    public String getStatus() {
        return status;
    }

    /**
     * @return the capacity
     */
    public int getCapacity() {
        return capacity;
    }

    /**
     * @return the managerId
     */
    public String getManagerId() {
        return managerId;
    }

    @Override
    public String toString() {
        return "Train{" + "trainId=" + trainId + ", driverName=" + driverName + ", model=" + model + ", maxDistance=" + maxDistance + ", status=" + status + ", capacity=" + capacity + ", managerId=" + managerId + '}';
    }
}
