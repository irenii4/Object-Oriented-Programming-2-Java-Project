/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/GUIForms/JFrame.java to edit this template
 */
package trainx_project;

import net.proteanit.sql.DbUtils;
import java.sql.*;
import java.util.*;
import javax.swing.*;
import javax.swing.table.*;
import static trainx_project.UserLogin.*;
import static trainx_project.DBConnectionAndQueries.*;

/**
 *
 * @author Imtinan Alhajri
 */
public class PassDeleteTicket  extends javax.swing.JFrame {
    public static String Pass_Id;
    /**
     * Creates new form DleteTicket
     */
    public PassDeleteTicket (String Pass_Id) {
        this.Pass_Id = Pass_Id;
        initComponents();
        DBConnectionAndQueries con = new DBConnectionAndQueries();
       
        ArrayList<String> bookings = con.getPassBookings(Pass_Id);
       
        ArrayList<Tickets> tickets = con.getTickets(bookings);
        loadTicketsData(tickets);   
    }
      
    
    
    
     
    
    private void loadTicketsData(ArrayList<Tickets> tickets) {
    try {
        if (tickets != null && !tickets.isEmpty()) {
            // Convert the ArrayList<Tickets> to an Object[][] 
            Object[][] ticketData = new Object[tickets.size()][6]; //  size based on columns
            
            for (int i = 0; i < tickets.size(); i++) {
                Tickets t = tickets.get(i);
                ticketData[i][0] = t.getTicket_Id();       
                ticketData[i][1] = t.getClass_Type();
                ticketData[i][2] = t.getClass_Price();
                ticketData[i][3] = t.getSeat_Number();
                ticketData[i][4] = t.getBooking_Number();
                ticketData[i][5] = t.getTravel_date();
            }
            
            // Set the model to the JTable
            PassengerTickets.setModel(new DefaultTableModel(ticketData, new String[] {
                "Ticket ID", "Class Type", "Class Price", "Seat Number", "Booking Number","Travel_Date"
            }));
        } else {
            JOptionPane.showMessageDialog(this, "You Dont Have any Tickets toDelete.");
        }
    } catch (Exception e) {
        e.printStackTrace();
    }
}
private void deleteSelectedRow() {
    int[] selectedRows = PassengerTickets.getSelectedRows();
    if (selectedRows.length > 0) {
        int confirm = JOptionPane.showConfirmDialog(null,
                "Are you sure you want to delete the selected Tickets?", "Confirm Delete",
                JOptionPane.YES_NO_OPTION);

        if (confirm == JOptionPane.YES_OPTION) {
            try (Connection conn = DBConnectionAndQueries.getConnection()) {
                conn.setAutoCommit(false); // Start the transaction
                String deleteQuery = "DELETE FROM Tickets WHERE Ticket_Id = ?";
                String updateQuery = "UPDATE Booking SET Number_of_Passengers = Number_of_Passengers - ?  WHERE Booking_Number = ?";

                try (PreparedStatement stmt = conn.prepareStatement(deleteQuery);
                     PreparedStatement stmt2 = conn.prepareStatement(updateQuery)) {

                    DefaultTableModel model = (DefaultTableModel) PassengerTickets.getModel();
                    HashSet<String> processedBookings = new HashSet<>(); // Track processed bookings

                    // Process in reverse order to avoid index issues after deletion
                    for (int i = selectedRows.length - 1; i >= 0; i--) {
                        int selectedRow = selectedRows[i];
                        String ticketId = (String) PassengerTickets.getValueAt(selectedRow, 0); // Ticket Id
                        String bNO = (String) PassengerTickets.getValueAt(selectedRow, 4); // Booking Number

                        stmt.setString(1, ticketId);
                        stmt.addBatch(); // Add to batch for better execution

                        model.removeRow(selectedRow); // Remove from JTable
                        

                        // Decrement passengers only once per booking number
                        if (!processedBookings.contains(bNO)) {
                            int ticketCount = selectedRows.length; // total number of selected tickets
                            stmt2.setInt(1, ticketCount);
                            stmt2.setString(2, bNO);
                            stmt2.addBatch(); 
                            processedBookings.add(bNO); // Mark booking as processed
                        }
                    }

                    stmt.executeBatch();
                    stmt2.executeBatch();
                    conn.commit(); // Commit transaction
                    JOptionPane.showMessageDialog(null, "Tickets deleted successfully.");

                } catch (SQLException ex) {
                    conn.rollback(); // Rollback transaction in case of error
                    ex.printStackTrace();
                    JOptionPane.showMessageDialog(null, "Error deleting Tickets: " + ex.getMessage());
                } finally {
                    conn.setAutoCommit(true); // Reset auto-commit
                }
            } catch (SQLException ex) {
                ex.printStackTrace();
                JOptionPane.showMessageDialog(null, "Database connection error: " + ex.getMessage());
            }
        }
    } else {
        JOptionPane.showMessageDialog(null, "No Tickets selected.");
    }
}
    


    /**
     * This method is called from within the constructor to initialize the form.
     * WARNING: Do NOT modify this code. The content of this method is always
     * regenerated by the Form Editor.
     */
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jLabel2 = new javax.swing.JLabel();
        jOptionPane1 = new javax.swing.JOptionPane();
        jScrollPane1 = new javax.swing.JScrollPane();
        jTable1 = new javax.swing.JTable();
        jScrollPane2 = new javax.swing.JScrollPane();
        jTextArea1 = new javax.swing.JTextArea();
        jTextField1 = new javax.swing.JTextField();
        jLabel3 = new javax.swing.JLabel();
        jPanel1 = new javax.swing.JPanel();
        jLabel1 = new javax.swing.JLabel();
        jButton2 = new javax.swing.JButton();
        jButton1 = new javax.swing.JButton();
        jLabel5 = new javax.swing.JLabel();
        jScrollPane3 = new javax.swing.JScrollPane();
        PassengerTickets = new javax.swing.JTable();
        jLabel4 = new javax.swing.JLabel();

        jLabel2.setFont(new java.awt.Font("Helvetica Neue", 0, 18)); // NOI18N
        jLabel2.setText("Leaving so soon");

        jTable1.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null}
            },
            new String [] {
                "Title 1", "Title 2", "Title 3", "Title 4"
            }
        ));
        jScrollPane1.setViewportView(jTable1);

        jTextArea1.setColumns(20);
        jTextArea1.setRows(5);
        jScrollPane2.setViewportView(jTextArea1);

        jTextField1.setColumns(15);

        jLabel3.setFont(new java.awt.Font("Songti SC", 1, 14)); // NOI18N
        jLabel3.setText("Enter Your Booking ID");

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);
        setBackground(new java.awt.Color(255, 255, 255));
        getContentPane().setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        jPanel1.setBackground(new java.awt.Color(255, 255, 255));
        jPanel1.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        jLabel1.setFont(new java.awt.Font("Times New Roman", 1, 24)); // NOI18N
        jLabel1.setText("Delete Your Trip");
        jPanel1.add(jLabel1, new org.netbeans.lib.awtextra.AbsoluteConstraints(300, 30, -1, -1));

        jButton2.setFont(new java.awt.Font("Times New Roman", 1, 14)); // NOI18N
        jButton2.setForeground(new java.awt.Color(51, 204, 0));
        jButton2.setText("Return");
        jButton2.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton2ActionPerformed(evt);
            }
        });
        jPanel1.add(jButton2, new org.netbeans.lib.awtextra.AbsoluteConstraints(440, 390, 140, -1));

        jButton1.setFont(new java.awt.Font("Times New Roman", 1, 14)); // NOI18N
        jButton1.setForeground(new java.awt.Color(255, 102, 102));
        jButton1.setText("Delete My Trip");
        jButton1.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton1ActionPerformed(evt);
            }
        });
        jPanel1.add(jButton1, new org.netbeans.lib.awtextra.AbsoluteConstraints(240, 390, 140, -1));

        jLabel5.setFont(new java.awt.Font("Times New Roman", 1, 16)); // NOI18N
        jLabel5.setText("Found Trip:");
        jPanel1.add(jLabel5, new org.netbeans.lib.awtextra.AbsoluteConstraints(30, 130, 110, -1));

        PassengerTickets.setAutoCreateRowSorter(true);
        PassengerTickets.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {
                {null, null, null, null, null, null},
                {null, null, null, null, null, null},
                {null, null, null, null, null, null},
                {null, null, null, null, null, null}
            },
            new String [] {
                "TicketId", "Class_Type", "Class_Price", "Seat_Number", "Booking_Number", "Train_Id"
            }
        ) {
            Class[] types = new Class [] {
                java.lang.String.class, java.lang.Object.class, java.lang.Object.class, java.lang.Object.class, java.lang.Object.class, java.lang.Object.class
            };

            public Class getColumnClass(int columnIndex) {
                return types [columnIndex];
            }
        });
        PassengerTickets.setSelectionMode(javax.swing.ListSelectionModel.MULTIPLE_INTERVAL_SELECTION);
        PassengerTickets.setSelectionMode(javax.swing.ListSelectionModel.MULTIPLE_INTERVAL_SELECTION);
        PassengerTickets.setShowGrid(false);
        jScrollPane3.setViewportView(PassengerTickets);

        jPanel1.add(jScrollPane3, new org.netbeans.lib.awtextra.AbsoluteConstraints(120, 130, 560, 210));

        jLabel4.setIcon(new javax.swing.ImageIcon(getClass().getResource("/trainx_project/logoResized.jpg"))); // NOI18N
        jPanel1.add(jLabel4, new org.netbeans.lib.awtextra.AbsoluteConstraints(20, 350, -1, 120));

        getContentPane().add(jPanel1, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 2, 800, 500));

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void jButton2ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton2ActionPerformed

        this.setVisible(false);
        PassMainPage p = new PassMainPage(Pass_Id);
        p.setVisible(true);
        p.setLocationRelativeTo(this);
        p.setSize(800, 500);
        p.setResizable(false);
    }//GEN-LAST:event_jButton2ActionPerformed

    private void jButton1ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton1ActionPerformed
        deleteSelectedRow();
    }//GEN-LAST:event_jButton1ActionPerformed

    /**
     * @param args the command line arguments
     */
    public static void main(String args[]) {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(PassDeleteTicket .class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(PassDeleteTicket .class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(PassDeleteTicket .class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(PassDeleteTicket .class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>

        /* Create and display the form */
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new PassDeleteTicket (Pass_Id).setVisible(true);
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    public static javax.swing.JTable PassengerTickets;
    private javax.swing.JButton jButton1;
    private javax.swing.JButton jButton2;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JLabel jLabel3;
    private javax.swing.JLabel jLabel4;
    private javax.swing.JLabel jLabel5;
    private javax.swing.JOptionPane jOptionPane1;
    private javax.swing.JPanel jPanel1;
    private javax.swing.JScrollPane jScrollPane1;
    private javax.swing.JScrollPane jScrollPane2;
    private javax.swing.JScrollPane jScrollPane3;
    private javax.swing.JTable jTable1;
    private javax.swing.JTextArea jTextArea1;
    private javax.swing.JTextField jTextField1;
    // End of variables declaration//GEN-END:variables
}
