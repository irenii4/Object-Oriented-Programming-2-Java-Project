/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package trainx_project;
import java.math.BigDecimal;
import java.sql.*;
import java.time.LocalDate;
import java.time.LocalTime;
import java.util.*;
import javax.swing.JOptionPane;
import javax.swing.JTable;
import net.proteanit.sql.DbUtils;
import java.sql.Date;
import java.sql.SQLException;
import java.sql.Time;
import java.time.LocalDate;
import java.time.LocalTime;

/**
 *
 * @author Imtinan Alhajri
 */

public class DBConnectionAndQueries {
    private static Connection connection;
    PreparedStatement getPassengers;
    PreparedStatement getManagers;
    PreparedStatement getTicketsOnBookings;
    PreparedStatement getPassBookings;
    PreparedStatement selectAllTrainsStatement;
    private PreparedStatement getBookings;
    private PreparedStatement getTickets;
    private PreparedStatement getTrips;
    private PreparedStatement getSpecificTrip;
    
    private PreparedStatement deleteTickets;
    private PreparedStatement updatebookings;
    private PreparedStatement generateTickets;
    
    private PreparedStatement getSelectedSeats;
    private PreparedStatement insertPayment;
    private PreparedStatement bookingStmt;
    private static PreparedStatement getBookingNum;
    private PreparedStatement ticketStmt;
    private PreparedStatement paymentStmt;
    private PreparedStatement getStationServices;
   

    
    
    static String url = "jdbc:mysql://localhost:3306/TrainX_DB2"; 
    static  String user = "root"; 
    static String password = "AA5011yy!";

    public DBConnectionAndQueries() {
  
        try {
            connection = DriverManager.getConnection(url, user, password);
            System.out.println("Database connected successfully!");
            
            getPassengers=connection.prepareStatement("SELECT * FROM Passenger WHERE Passenger_Id = ?");
            getManagers=connection.prepareStatement("SELECT * FROM Managers WHERE Manager_Id = ?");
            getTicketsOnBookings = connection.prepareStatement("SELECT * FROM Tickets WHERE Booking_Number=?");
            getPassBookings= connection.prepareStatement("SELECT * FROM Booking WHERE Passenger_Id = ?");
            selectAllTrainsStatement= connection.prepareStatement("SELECT * FROM Train");
            getBookings=connection.prepareStatement("SELECT * FROM Booking WHERE Passenger_Id=?");
            //return tickets relevent with Booking_Number
            getTickets=connection.prepareStatement("SELECT * FROM Tickets WHERE Booking_Number = ?");
            //return Trips with specified destination and 
            getTrips=connection.prepareStatement("SELECT * FROM Schedules WHERE Route_From =? AND Route_To=? AND Departure=?;");
            
            //return one trip (route) based on trip id & travel date
            getSpecificTrip=connection.prepareStatement("SELECT Departure,Trip_Total_Time,Route_From,Route_To,Train_Id "
                    + "FROM Schedules "
                    + "WHERE Train_Id = ? && Departure = ?");
            
            deleteTickets=connection.prepareStatement("DELETE FROM Tickets WHERE Booking_Number = ?");
            updatebookings=connection.prepareStatement("UPDATE Booking SET Number_of_Passengers= ? , Booking_Date=curdate() "
                    + "WHERE Booking_Number=?");
            generateTickets=connection.prepareStatement(
                    "INSERT INTO Tickets ( Class_Type, Class_Price, Seat_Number, Booking_Number, Train_ID, Travel_date) "
                            + "VALUES (?, ?, ?, ?, ?, ?)");
            
            
            //to get the selected seats in a specific trip
            getSelectedSeats=connection.prepareStatement("SELECT Seat_Number FROM Tickets  WHERE Train_Id = ? && Travel_date = ?");
            bookingStmt = connection.prepareStatement("INSERT INTO Booking (Booking_Date, Number_of_Passengers, Passenger_Id) VALUES (?, ?, ?)");
            getBookingNum = connection.prepareStatement("SELECT MAX(Booking_Number) FROM Booking WHERE Passenger_Id = ?");
            
            ticketStmt = connection.prepareStatement("INSERT INTO Tickets (Class_Type, Class_Price, Seat_Number, Booking_Number, Train_ID, Travel_date) VALUES (?, ?, ?, ?, ?, ?)");
            paymentStmt = connection.prepareStatement("INSERT INTO Payment (Booking_Number, Amount, Payment_Date, Payment_Time) VALUES (?, ?, ?, ?)");
            //ViewAllTrains = connection.prepareStatement("SELECT Train_id, Driver_Name, Capacity, Max_Distance, Model, Train_Status, Manager_Id FROM Train");
            insertPayment=connection.prepareStatement("INSERT INTO Payment (Amount , Payment_Date, Payment_Time, Booking_Number) VALUES(? ,?,?,?)");
            getStationServices=connection.prepareStatement("select * from Services where Station_Id=?");
            
        } catch (SQLException ex) {
            ex.printStackTrace();
            System.exit(1); 
        }
    }

    // Method to get the existing connection
    public static Connection getConnection() throws SQLException {
        return connection = DriverManager.getConnection(url, user, password);
    }
    public void updateStationTable(JTable table,int stationId){
       ResultSet resultSet=null;
       
       try{
            getStationServices.setInt(1, stationId);
            resultSet=getStationServices.executeQuery();
            
            table.setModel(DbUtils.resultSetToTableModel(resultSet));
            
       }catch(SQLException sqlException){
                System.out.print("\nSQLException in updateStationTable");
                sqlException.printStackTrace();
                System.exit(1);
            }finally{
                
                try{
                    resultSet.close();
                }catch(SQLException sqlException){
                    sqlException.printStackTrace();
                    closeConnection(); 
                }
            }
   } // end of updateStationTable
    
    public void insertNewUser(String firstName, String lastName, String password, java.util.Date birthDate, DBConnectionAndQueries con) {
    try {
        
        connection =getConnection();
        if (connection == null) {
            JOptionPane.showMessageDialog(null, "Failed to connect to database.");
            return;
        }

        
        String sql = "INSERT INTO passenger (First_name, Last_name, Passenger_Pass, PassengerDOB) VALUES (?, ?, ?, ?)";
        PreparedStatement pstmt = connection.prepareStatement(sql);
        pstmt.setString(1, firstName);
        pstmt.setString(2, lastName);
        pstmt.setString(3, password);
        pstmt.setDate(4, new java.sql.Date(birthDate.getTime()));

        
        int rowsInserted = pstmt.executeUpdate();
        if (rowsInserted > 0) {
            javax.swing.JOptionPane.showMessageDialog(null, "Sign Up Successful!");
            
            UserLogin l = new UserLogin();
            l.setLocationRelativeTo(l);
            String getPassId = "SELECT Passenger_ID FROM passenger WHERE First_name = ? AND Last_name = ? AND PassengerDOB = ? ORDER BY Passenger_ID DESC LIMIT 1";
            PreparedStatement stmt = connection.prepareStatement(getPassId);
            stmt.setString(1, firstName);
            stmt.setString(2, lastName);
            stmt.setDate(3, new java.sql.Date(birthDate.getTime()));
            ResultSet rs = stmt.executeQuery();
            
            if (rs.next()) {
                String passengerId = rs.getString("Passenger_Id");
                JOptionPane.showMessageDialog(null, 
                    "Sign Up Successful!\nYour Passenger ID is: " + passengerId +
                    "\nPlease save this ID for logging in next time.");
            } else {
                JOptionPane.showMessageDialog(null, "Sign Up successful but failed to retrieve your ID.");
            }


        } else {
            javax.swing.JOptionPane.showMessageDialog(null, "Failed to sign up. Try again.");
        }

        connection.close();
    } catch (Exception e) {
        e.printStackTrace();
        javax.swing.JOptionPane.showMessageDialog(null, "Database error: " + e.getMessage());
    }
    }

    
    public static ResultSet getAllTrains() {
        
        PreparedStatement selectAllTrainsStatement = null;
        ResultSet resultSet = null;

        try {
            connection = getConnection();
            selectAllTrainsStatement = connection.prepareStatement("SELECT * FROM Train");
            resultSet = selectAllTrainsStatement.executeQuery();
            return resultSet; // Return the ResultSet

        } catch (SQLException e) {
            e.printStackTrace();
            return null; 
        } 
    }
    public boolean savePayment(double amount, String bookingNumber) {
    try {
        
        insertPayment.setDouble(1, amount);

        
        java.sql.Date sqlDate = Date.valueOf(LocalDate.now());
        insertPayment.setDate(2, sqlDate);

        
        Time sqlTime = Time.valueOf(LocalTime.now());
        insertPayment.setTime(3, sqlTime);

        insertPayment.setString(4, bookingNumber);

        int rowsInserted = insertPayment.executeUpdate();
        return rowsInserted > 0;

    } catch (SQLException e) {
        e.printStackTrace();
        return false;
    }
}

    
   
    public static ResultSet getAllBookings() {
        
        PreparedStatement getAllBookings = null;
        ResultSet resultSet = null;

        try {
            connection = getConnection();
            getAllBookings = connection.prepareStatement("SELECT * FROM Booking");
            resultSet = getAllBookings.executeQuery();
            return resultSet;

        } catch (SQLException e) {
            e.printStackTrace();
            return null; 
        } 
    }
    
    public boolean insertNewBookings(LocalDate travelDate, String fromCity, String toCity, String trainRoute,
                                  LocalDate returnDate, double totalPrice, int selectedSeats, String passengerId) {

        Connection connection = null;
        PreparedStatement preparedStatement = null;
        boolean successful = false;

        try {
            connection = getConnection();


            // Get today's date
            LocalDate bookingDate = LocalDate.now();

            //Number of passengers
            int numberOfPassengers = selectedSeats;

            String sql = "INSERT INTO Booking (Booking_Date, Number_of_Passengers, Passenger_Id) VALUES (?, ?, ?)";
            preparedStatement = connection.prepareStatement(sql);
            preparedStatement.setObject(1, bookingDate); // Use setObject for LocalDate
            preparedStatement.setInt(2, numberOfPassengers);
            preparedStatement.setString(3, passengerId);

            int rowsAffected = preparedStatement.executeUpdate();

            if (rowsAffected > 0) {
                JOptionPane.showMessageDialog(null, "Booking added successfully!","Booking Confirmation", JOptionPane.INFORMATION_MESSAGE);
                successful=true;
            } else {
                JOptionPane.showMessageDialog(null, "Failed to add booking.", "Booking Error", JOptionPane.ERROR_MESSAGE);
                successful=false;
            
            }
            

        } catch (SQLException e) {
            JOptionPane.showMessageDialog(null, "Database error: " + e.getMessage(), "Database Error", JOptionPane.ERROR_MESSAGE);
            e.printStackTrace();
        } finally {
            try {
                if (preparedStatement != null) {
                    preparedStatement.close();
                }
                if (connection != null) {
                    connection.close();
                }
            } catch (SQLException ex) {
                ex.printStackTrace();
            }
        }
        return successful ;
        
    }
    public ArrayList<Booking> getBookings(String Passenger_Id) {
    Connection connection = null;
    PreparedStatement getBookings = null; 
    ArrayList<Booking> result = new ArrayList<>();
    ResultSet resultSet = null;

    try {
        connection = getConnection(); 
        String sql = "SELECT Booking_Number, Booking_Date, Number_of_Passengers, Passenger_Id FROM Bookings WHERE Passenger_Id = ?"; 
        getBookings = connection.prepareStatement(sql); 
        getBookings.setString(1, Passenger_Id);
        resultSet = getBookings.executeQuery();

        while (resultSet.next()) {
            Booking booking = new Booking(
                    resultSet.getString("Booking_Number"),
                    resultSet.getDate("Booking_Date"),
                    resultSet.getInt("Number_of_Passengers"),
                    resultSet.getString("Passenger_Id")
            );
            result.add(booking);
        }

        for (Booking b : result) {
            System.out.println(b);
        }

    } catch (SQLException sqlException) {
        System.out.println("\nSQLException in getBookings");
        sqlException.printStackTrace();
    } finally {
        try {
            if (resultSet != null) {
                resultSet.close();
            }
            if (getBookings != null) {
                getBookings.close();
            }
            if (connection != null) {
                connection.close(); 
            }
        } catch (SQLException sqlException) {
            sqlException.printStackTrace();
        }
    }

    return result;
}
   


public ArrayList<String> getPassBookings(String passId) {
    ArrayList<String> bookings = new ArrayList<>();
    ResultSet resultSet = null;

    try {
       
        
        getPassBookings.setString(1, passId); 
        resultSet = getPassBookings.executeQuery();

        while (resultSet.next()) {
            bookings.add(
                resultSet.getString("Booking_Number")
                
            );
        }

    } catch (SQLException sqlException) {
        System.out.print("\nSQLException in getPassBookings");
        sqlException.printStackTrace();
    } finally {
        try {
            if (resultSet != null) {
                resultSet.close();
            }
            if (getPassBookings != null) {
                getPassBookings.close(); 
            }
        } catch (SQLException sqlException) {
            sqlException.printStackTrace();
        }
    }

    return bookings; // Return the list of bookings
}
    
    
    
    
    
    public ArrayList<Person> getAllPassengers() {
    ArrayList<Person> passengers = new ArrayList<>();
    ResultSet resultSet = null;

    try {
        PreparedStatement getAllPassengers = connection.prepareStatement("SELECT DISTINCT * FROM Passenger");
        resultSet = getAllPassengers.executeQuery();

        while(resultSet.next()){
                    passengers.add(new Person(
                        resultSet.getString("Passenger_Id"),
                        resultSet.getString("Passenger_Pass"),
                        resultSet.getString("First_Name"),
                        resultSet.getString("Last_Name"),
                        resultSet.getDate("PassengerDOB")   
                        
                    ));           
        }
        for(Person t: passengers)
                    System.out.println(t);
    } catch (SQLException e) {
        e.printStackTrace();
    } finally {
        try {
            if (resultSet != null) {
                resultSet.close();
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    return passengers;
}
    public ArrayList<Manager> getAllManagers() {
    ArrayList<Manager> managers = new ArrayList<>();
    ResultSet resultSet = null;

    try {
        PreparedStatement getAllManagers = connection.prepareStatement("SELECT DISTINCT* FROM Managers");
        resultSet = getAllManagers.executeQuery();

        while(resultSet.next()){
                    managers.add(new Manager(
                        resultSet.getString("Manager_Id"),
                        resultSet.getString("Manager_Password"),
                        resultSet.getString("First_Name"),
                        resultSet.getString("Last_Name"),
                        resultSet.getString("Email"),
                        resultSet.getString("Phone_Number"),
                        resultSet.getDate("Birth_Date"),
                        resultSet.getDouble("Salary")
                        
                    ));
                    
        }
        for(Manager t:managers)
                    System.out.println(t);
    } catch (SQLException e) {
        e.printStackTrace();
    } finally {
        try {
            if (resultSet != null) {
                resultSet.close();
            }
            
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    return managers;
}
    
     public ArrayList<Person> getPassenger(String Passenger_Id){
            ArrayList<Person> result=null;
            ResultSet resultSet=null;
            
            try{
                getPassengers.setString(1, Passenger_Id);
                resultSet=getPassengers.executeQuery();
            
                result=new ArrayList<Person>();
                
                
                while(resultSet.next()){
                    result.add(new Person(
                        resultSet.getString("Passenger_Id"),
                        resultSet.getString("Passenger_Pass"),
                        resultSet.getString("First_Name"),
                        resultSet.getString("Last_Name"),
                        resultSet.getDate("PassengerDOB")   
                        
                    ));}
                
                
            }catch(SQLException sqlException){
                System.out.print("\nSQLException in getTickets");
                sqlException.printStackTrace();
                System.exit(1);
            }finally{
                System.out.print("\n\nfinally block");
                try{
                    resultSet.close();
                }catch(SQLException sqlException){
                    sqlException.printStackTrace();
                    closeConnection();
                }
            }
          
            return result;
    }
     // method to return all the tickets for a booking number
    public ArrayList<Tickets> getTickets(String Booking_Number){
            ArrayList<Tickets> result=null;
            ResultSet resultSet=null;
            
            try{
                getTickets.setString(1, Booking_Number);
                resultSet=getTickets.executeQuery();
            
                result=new ArrayList<Tickets>();
                
                
                //add Tkicket values from the DB
                while(resultSet.next()){
                    result.add(new Tickets(
                        resultSet.getString("Ticket_Id"),
                        resultSet.getString("Class_Type"),
                        resultSet.getDouble("Class_Price"),
                        resultSet.getString("Seat_Number"),
                        resultSet.getString("Booking_Number"),
                        resultSet.getInt("Train_Id"), 
                        resultSet.getDate("Travel_date")
                    ));}
                
               for(Tickets t:result)
                    System.out.println(t);
                
            }catch(SQLException sqlException){
                System.out.print("\nSQLException in getTickets");
                sqlException.printStackTrace();
                System.exit(1);
            }finally{
                //System.out.print("\n\nfinally block");
                try{
                    resultSet.close();
                }catch(SQLException sqlException){
                    sqlException.printStackTrace();
                    closeConnection(); 
                }
            }
          
            return result;
    }//end of getTickets method, R: ArrayList<Tickets>
    
    
    //Method to return all the tickets for a passenger based on thier booking numbers
    public ArrayList<Tickets> getTickets(ArrayList<String> bookingNumbers) {
    ArrayList<Tickets> result = new ArrayList<>(); 
    ResultSet resultSet = null;
    

    try {
        
        String query = "SELECT * FROM tickets WHERE Booking_Number = ?";
        getTicketsOnBookings = connection.prepareStatement(query);

       
        for (String bookingNumber : bookingNumbers) {
            getTicketsOnBookings.setString(1, bookingNumber); 
            resultSet = getTicketsOnBookings.executeQuery();

           
            while (resultSet.next()) {
                result.add(new Tickets(
                    resultSet.getString("Ticket_Id"),
                    resultSet.getString("Class_Type"),
                    resultSet.getDouble("Class_Price"),
                    resultSet.getString("Seat_Number"),
                    resultSet.getString("Booking_Number"),
                    resultSet.getInt("Train_Id") ,
                    resultSet.getDate("Travel_date")
                        
                ));
            }
        }

        for (Tickets t : result) {
            System.out.println(t);
        }

    } catch (SQLException sqlException) {
        System.out.print("\nSQLException in getTickets");
        sqlException.printStackTrace();
        System.exit(1);
    } finally {
        System.out.print("\n\nfinally block");
        try {
            if (resultSet != null) {
                resultSet.close();
            }
            if (getTickets != null) {
                getTickets.close(); 
            }
        } catch (SQLException sqlException) {
            sqlException.printStackTrace();
            closeConnection(); 
        }
    }

    return result; // Return the list of tickets    
}
    public ArrayList<Schedules> getTripsOneRoute(String from, String to,java.sql.Date date){ 
            ArrayList<Schedules> result=null;
            ResultSet resultSet=null;
            
            try{
                getTrips.setString(1, from);
                getTrips.setString(2, to);
                getTrips.setDate(3, date);
                resultSet=getTrips.executeQuery();
            
                result=new ArrayList<Schedules>();
                
                //add Tkicket values from the DB
                while(resultSet.next()){
                    result.add(new Schedules(
                            resultSet.getInt("Schedule_id"),
                            resultSet.getDate("Departure"),
                            resultSet.getDate("Arrival"),
                            resultSet.getString("Trip_Total_Time"),
                            resultSet.getString("Route_From"),
                            resultSet.getString("Route_To"),
                            resultSet.getInt("Route_Distance"),
                            resultSet.getInt("Train_Id")
                    ));}
                
               for(Schedules s:result)
                    System.out.println(s);
                
            }catch(SQLException sqlException){
                System.out.print("\nSQLException in getTrips");
                sqlException.printStackTrace();
                System.exit(1);
            }finally{
                //System.out.print("\n\nfinally block");
                try{
                    resultSet.close();
                }catch(SQLException sqlException){
                    sqlException.printStackTrace();
                    closeConnection(); 
                }
            }
          
            return result;
    }//end of getTripsOneRoute method, R: ArrayList<Schedules>
    
     public Schedules getSpecificTrip(int TrainId, java.sql.Date depature){
            Schedules result=null;
            ResultSet resultSet=null;
          
            try{
                getSpecificTrip.setInt(1, TrainId);
                getSpecificTrip.setDate(2, depature);
                resultSet=getSpecificTrip.executeQuery();
            
                if (resultSet.next()) {
                result = new Schedules(
                resultSet.getDate("Departure"),
                resultSet.getString("Trip_Total_Time"),
                resultSet.getString("Route_From"),
                resultSet.getString("Route_To"),
                resultSet.getInt("Train_Id")
            );
        }

        System.out.println("Schedule fetched: " + result);
                
            }catch(SQLException sqlException){
                System.out.print("\nSQLException in getSpecificTrips");
                sqlException.printStackTrace();
                System.exit(1);
            }finally{
                //System.out.print("\n\nfinally block");
                try{
                    resultSet.close();
                }catch(SQLException sqlException){
                    sqlException.printStackTrace();
                    closeConnection(); 
                }
            }
          
            return result;
    }//end of getSpecificTrip method, R: Schedules Object
    
    
  
   public void updateTable(JTable table,String Booking_Number){
       ResultSet resultSet=null;
       
       try{
            getTickets.setString(1, Booking_Number);
            resultSet=getTickets.executeQuery();
            table.setModel(DbUtils.resultSetToTableModel(resultSet));
            table.setEnabled(false);//only allowed to view the tickets
       }catch(SQLException sqlException){
                System.out.print("\nSQLException in getSpecificTrips");
                sqlException.printStackTrace();
                System.exit(1);
            }finally{
                //System.out.print("\n\nfinally block");
                try{
                    resultSet.close();
                }catch(SQLException sqlException){
                    sqlException.printStackTrace();
                    closeConnection(); 
                }
            }
   } // end of updateTable
   
   public int updateFoundTrips(JTable table,String from, String to,java.sql.Date date){
       ResultSet resultSet=null;
       int tripFound=-1;
       
       try{
            getTrips.setString(1, from);
            getTrips.setString(2, to);
            getTrips.setDate(3, date);
            resultSet=getTrips.executeQuery();
            
            
            
            table.setModel(DbUtils.resultSetToTableModel(resultSet));
           if(resultSet.next()){
                tripFound=5;
                resultSet.absolute(-1);
            }
       }catch(SQLException sqlException){
                System.out.print("\nSQLException in updateFoundTrips");
                sqlException.printStackTrace();
                System.exit(1);
            }finally{
                //System.out.print("\n\nfinally block");
                try{
                    resultSet.close();
                }catch(SQLException sqlException){
                    sqlException.printStackTrace();
                    closeConnection(); 
                }
            }
       return tripFound;
   } // end of updateFoundTrips, R:int
    
   
   public int deleteOldTickets(String bookingNumber,ArrayList<String> seatsClass,ArrayList<String> seatsNum,
                                int trainId,java.sql.Date travelDate, ArrayList<Double>ticketFee)
   {
       
       
       int ticketsDeleted=0;
       int updateBooking=0;
       int ticketsGenerated=0;
       
       int numOfPassangers=0;
       
          
            try{
                // 1. delete the old tickets
                deleteTickets.setString(1, bookingNumber);
                ticketsDeleted=deleteTickets.executeUpdate();
                
                // 2. update the booking table information
                numOfPassangers=seatsNum.size();
                updatebookings.setInt(1, numOfPassangers);
                updatebookings.setString(2, bookingNumber);
                updateBooking=updatebookings.executeUpdate();
                  
                // 3. generate new Tickets
                for (int i=0;i<numOfPassangers;i++){
                    //fill the values
                    generateTickets.setString(1, seatsClass.get(i));
                    generateTickets.setDouble(2, ticketFee.get(i));
                    generateTickets.setString(3, seatsNum.get(i));
                    generateTickets.setString(4, bookingNumber);
                    generateTickets.setInt(5, trainId);
                    generateTickets.setDate(6, travelDate);
                    
                    //Insert
                    ticketsGenerated=generateTickets.executeUpdate();
                }
                
            }catch(SQLException sqlException){
                System.out.print("\nSQLException in getSpecificTrips");
                sqlException.printStackTrace();
                closeConnection(); 
            }
            
            
            if(ticketsDeleted<0 || updateBooking<0 || ticketsGenerated<0){
                return -1;
            }
            else 
                return 1;
    }//end of deleteOldTickets method, R: int
   
   public int deleteOldTickets(String bookingNumber,ArrayList<String> seatsClass,ArrayList<String> seatsNum,
                                int trainId,java.sql.Date travelDate, ArrayList<Double>ticketFee,int returnTrainId, java.sql.Date returnDate)
   {
       
       
       int ticketsDeleted=0;
       int updateBooking=0;
       int ticketsGenerated=0;
       
       
       int numOfPassangers=0;
       
            
            
          
            try{
                // 1. delete the old tickets
                deleteTickets.setString(1, bookingNumber);
                ticketsDeleted=deleteTickets.executeUpdate();
                
                // 2. update the booking table information
                numOfPassangers=seatsNum.size();
                updatebookings.setInt(1, numOfPassangers);
                updatebookings.setString(2, bookingNumber);
                updateBooking=updatebookings.executeUpdate();
                  
                // 3. generate new Tickets
                //3.1 first Trip 
                for (int i=0;i<numOfPassangers;i++){
                    //fill the values
                    generateTickets.setString(1, seatsClass.get(i));
                    generateTickets.setDouble(2, ticketFee.get(i));
                    generateTickets.setString(3, seatsNum.get(i));
                    generateTickets.setString(4, bookingNumber);
                    generateTickets.setInt(5, trainId);
                    generateTickets.setDate(6, travelDate);
                    
                    //Insert
                    ticketsGenerated=generateTickets.executeUpdate();
                }
                
                //3.2 Return Trip Trip 
                for (int i=0;i<numOfPassangers;i++){
                    //fill the values
                    generateTickets.setString(1, seatsClass.get(i));
                    generateTickets.setDouble(2, ticketFee.get(i));
                    generateTickets.setString(3, seatsNum.get(i));
                    generateTickets.setString(4, bookingNumber);
                    generateTickets.setInt(5, returnTrainId);
                    generateTickets.setDate(6, returnDate);
                    
                    //Insert
                    ticketsGenerated=generateTickets.executeUpdate();
                }
                
            }catch(SQLException sqlException){
                System.out.print("\nSQLException in getSpecificTrips");
                sqlException.printStackTrace();
                closeConnection(); 
            }
            
            
            if(ticketsDeleted<0 || updateBooking<0 || ticketsGenerated<0){
                return -1;
            }
            else 
                return 1;
    }//end of deleteOldTickets method, R: int
   
   public List<String> getSelectedSeats(int traidId,java.sql.Date travelDate)
   {
       ArrayList<String> result=null;
       ResultSet resultSet=null;
       
       try{
                getSelectedSeats.setInt(1, traidId);
                getSelectedSeats.setDate(2, travelDate);
                resultSet=getSelectedSeats.executeQuery();
            
                result=new ArrayList<String>();
                
                while(resultSet.next()){
                    result.add(
                          resultSet.getString("Seat_Number")
                    );
                }
                
               for(String b:result)
                    System.out.println(b);
                
            
            }catch(SQLException sqlException){
                System.out.print("\nSQLException in getSelectedSeats");
                sqlException.printStackTrace();
                System.exit(1);
            }finally{
                //System.out.print("\n\nfinally block");
                try{
                    resultSet.close();
                }catch(SQLException sqlException){
                    sqlException.printStackTrace();
                    closeConnection();  
                }
            }
       
       
       return result;
   }//end of getSelectedSeats method, R: List<String>
    
    public boolean isTrainIdExists(int trainId) {
        try (Connection conn = DBConnectionAndQueries.getConnection()) {
            String query = "SELECT train_id FROM Train WHERE train_id = ?";
            try (PreparedStatement stmt = conn.prepareStatement(query)) {
                stmt.setInt(1, trainId);
                ResultSet rs = stmt.executeQuery();
                if(rs.next()){
                    return true;
                }
                else{
                    return false;
                }
            }
        } 
        catch (SQLException e) {
            e.printStackTrace();
            return false;
        }
    }


    // method to add a new train to the db
    public boolean addTrain(Train train) {
        try (Connection conn = DBConnectionAndQueries.getConnection()) {
            String query = "INSERT INTO Train (Train_Id, driver_name, model, max_distance, train_status, capacity, manager_id) VALUES (?, ?, ?, ?, ?, ?, ?)";
            try (PreparedStatement stmt = conn.prepareStatement(query)) {
                stmt.setInt(1, train.getTrainId());
                stmt.setString(2, train.getDriverName());
                stmt.setString(3, train.getModel());
                stmt.setInt(4, train.getMaxDistance());
                stmt.setString(5, train.getStatus());
                stmt.setInt(6, train.getCapacity());
                stmt.setString(7, train.getManagerId());

                int rowsAffected = stmt.executeUpdate();
                return rowsAffected > 0;  // returns true if train was added successfully
            }
        } catch (SQLException e) {
            e.printStackTrace();
            return false;
        }
    }
    
    // method to get all availabe train ids in the db currently to show in the train id jcombobox 
    public List<String> getAllTrainIds() {
        List<String> trainIds = new ArrayList<>();
        String query = "SELECT Train_Id FROM Train ORDER BY Train_Id ASC";

        try (Connection conn = DBConnectionAndQueries.getConnection();
            PreparedStatement pst = conn.prepareStatement(query);
            ResultSet rs = pst.executeQuery()) {

            while (rs.next()) {
                trainIds.add(""+(rs.getInt("Train_Id"))); // Convert int to String
            }
            
        } 
        catch (SQLException e) {
            e.printStackTrace();
        }
        return trainIds;
    }

    // method to get all details about the selected train 
    public Train getTrainById(int trainId) {
        Train train = null;
        String query = "SELECT * FROM Train WHERE Train_Id = ?";

        try (Connection conn = DBConnectionAndQueries.getConnection();
             PreparedStatement pst = conn.prepareStatement(query)) {

            pst.setInt(1, trainId);  
            ResultSet rs = pst.executeQuery();

            if (rs.next()) {
                // get the train details from the result set
                int id = rs.getInt("Train_Id");
                String driverName = rs.getString("Driver_Name");
                int capacity = rs.getInt("Capacity");
                int maxDistance = rs.getInt("Max_Distance");
                String model = rs.getString("Model");
                String status = rs.getString("Train_Status");
                String managerId = rs.getString("Manager_Id");

                // create a train object and set the fetched values
                train = new Train(id, driverName,capacity, maxDistance, model,  status, managerId);
                
            }
        }
        catch (SQLException e) {
            e.printStackTrace();
        }

        return train;
    }
    
    // method to update an exiting train 
    public boolean updateTrain(Train updatedTrain) {
        boolean isUpdated = false;
        String query = "UPDATE Train SET Driver_Name = ?,Capacity = ?, Max_Distance = ?, Model = ?, Train_Status = ?, Manager_id = ? WHERE Train_Id = ?";

        try (Connection conn = DBConnectionAndQueries.getConnection();
            PreparedStatement pst = conn.prepareStatement(query)) {

            // set the parameters for the prepared statement
            pst.setString(1, updatedTrain.getDriverName());
            pst.setInt(2, updatedTrain.getCapacity());
            pst.setInt(3, updatedTrain.getMaxDistance());
            pst.setString(4, updatedTrain.getModel());
            pst.setString(5, updatedTrain.getStatus());
            pst.setString(6, updatedTrain.getManagerId());
            pst.setInt(7, updatedTrain.getTrainId());

            int rowsAffected = pst.executeUpdate();
            if (rowsAffected > 0) {
                isUpdated = true;  // if train was successfully updated
            }
        }
        catch (SQLException e) {
            e.printStackTrace();
        }
        return isUpdated;
    }
     public int insertBknTknP(/////////////////////////////////NEW
        String passId, 
        List<String> seatsClass, 
        List<Double>ticketFee,
        List<String> seatsNum, // choosenSeats
        int trainId,// goTrainId
        Date travelDate,// travelDate
        BigDecimal amount // amount
    ) {
   
         int bookingGenerated=0;
         int ticketsGenerated=0;
         int paymentGenerated=0;
         
         int numOfPassangers=0;
         numOfPassangers=seatsNum.size();
         
        java.sql.Date todayDate = java.sql.Date.valueOf(java.time.LocalDate.now());
        java.sql.Time currentTime = java.sql.Time.valueOf(java.time.LocalTime.now());
        

        try {
            // insert booking
            bookingStmt.setDate(1, todayDate);
            bookingStmt.setInt(2, numOfPassangers);//  how many seats chosen 
            bookingStmt.setString(3, passId);
            bookingGenerated=bookingStmt.executeUpdate();

            // get the lateest bk of this pass
            getBookingNum.setString(1, passId);
            ResultSet rs = getBookingNum.executeQuery();
            String bookingNum = null;
            if (rs.next()) 
                bookingNum = rs.getString(1);
            try {
                if (rs != null)
                rs.close();
            } 
            catch (SQLException e){
                System.out.println("Database error:" + e.getMessage());
                e.printStackTrace();
            }

            for (int i=0;i<numOfPassangers;i++){
                    //fill the values
                    generateTickets.setString(1, seatsClass.get(i));
                    generateTickets.setDouble(2, ticketFee.get(i));
                    generateTickets.setString(3, seatsNum.get(i));////////////
                    generateTickets.setString(4, bookingNum);
                    generateTickets.setInt(5, trainId);
                    generateTickets.setDate(6, travelDate);
                    
                    //Insert
                    ticketsGenerated=generateTickets.executeUpdate();
                }

            // inserting payment
            insertPayment.setBigDecimal(1, amount);
            insertPayment.setDate(2, todayDate);
            insertPayment.setTime(3, currentTime);
            insertPayment.setString(4, bookingNum);
            //String sql = insertPayment.toString(); //
            //System.out.println("SQL Query: " + sql);
            
            insertPayment.executeUpdate();


        } catch (SQLException ex) {
            System.out.println("Database error:" + ex.getMessage());
            ex.printStackTrace();
        }
        
        if (bookingGenerated<0|| ticketsGenerated<0||  paymentGenerated<0){
        return -1;///////////////////////////////////////
    }else 
            return 1;
    }
     public int insertBknTknP(/////////////////////////////////NEW
        String passId, 
        List<String> seatsClass, 
        List<Double>ticketFee,
        List<String> seatsNum, // choosenSeats
        int trainId,// goTrainId
        Date travelDate,// travelDate
        BigDecimal amount ,int returnTrainId, Date returnDate// amount
    ) {
   
         int bookingGenerated=0;
         int ticketsGenerated=0;
         int paymentGenerated=0;
         
         int numOfPassangers=0;
         numOfPassangers=seatsNum.size();
         
        java.sql.Date todayDate = java.sql.Date.valueOf(java.time.LocalDate.now());
        java.sql.Time currentTime = java.sql.Time.valueOf(java.time.LocalTime.now());
        

        try {
            // insert booking
            bookingStmt.setDate(1, todayDate);
            bookingStmt.setInt(2, numOfPassangers);//  how many seats chosen 
            bookingStmt.setString(3, passId);
            bookingGenerated=bookingStmt.executeUpdate();

            // get the lateest bk of this pass
            getBookingNum.setString(1, passId);
            ResultSet rs = getBookingNum.executeQuery();
            String bookingNum = null;
            if (rs.next()) 
                bookingNum = rs.getString(1);
            try {
                if (rs != null)
                rs.close();
            } 
            catch (SQLException e){
                System.out.println("Database error:" + e.getMessage());
                e.printStackTrace();
            }

            for (int i=0;i<numOfPassangers;i++){
                    //fill the values
                    generateTickets.setString(1, seatsClass.get(i));
                    generateTickets.setDouble(2, ticketFee.get(i));
                    generateTickets.setString(3, seatsNum.get(i));////////////
                    generateTickets.setString(4, bookingNum);
                    generateTickets.setInt(5, trainId);
                    generateTickets.setDate(6, travelDate);
                    
                    //Insert
                    ticketsGenerated=generateTickets.executeUpdate();
                }
            for (int i=0;i<numOfPassangers;i++){
                    //fill the values
                    generateTickets.setString(1, seatsClass.get(i));
                    generateTickets.setDouble(2, ticketFee.get(i));
                    generateTickets.setString(3, seatsNum.get(i));////////////
                    generateTickets.setString(4, bookingNum);
                    generateTickets.setInt(5, returnTrainId);
                    generateTickets.setDate(6, returnDate);
                    
                    //Insert
                    ticketsGenerated=generateTickets.executeUpdate();
                }

            // inserting payment
            insertPayment.setBigDecimal(1, amount);
            insertPayment.setDate(2, todayDate);
            insertPayment.setTime(3, currentTime);
            insertPayment.setString(4, bookingNum);
            

            //String sql = insertPayment.toString(); // 
            //System.out.println("SQL Query: " + sql);
            
            paymentGenerated= insertPayment.executeUpdate();


        } catch (SQLException ex) {
            System.out.println("Database error:" + ex.getMessage());
            ex.printStackTrace();
        }
        
        if (bookingGenerated<0|| ticketsGenerated<0||  paymentGenerated<0){
        return -1;///////////////////////////////////////
    }else 
            return 1;
    }
     
     
     
     
     
     
     
     
     
     
     
     
     
     
     
     
     
     /*
     
     //*****************************************CHECKKK*********************************
     public static void insertPayment(String passId, BigDecimal amount) {
        PreparedStatement paymentStmt = null;
        int paymentGenerated = 0;

        try {
            
            java.sql.Date todayDate = java.sql.Date.valueOf(java.time.LocalDate.now());
            java.sql.Time currentTime = java.sql.Time.valueOf(java.time.LocalTime.now());
            String sql = "INSERT INTO Payment (Amount, Payment_Date, Payment_Time, Booking_Number) VALUES (?, ?, ?, ?)";
            getBookingNum.setString(1, passId);
            ResultSet rs = getBookingNum.executeQuery();
            String bookingNum = null;
            if (rs.next()) 
                bookingNum = rs.getString(1);
            try {
                if (rs != null)
                rs.close();
            } 
            catch (SQLException e){
                System.out.println("Database error:" + e.getMessage());
                e.printStackTrace();
            }

            paymentStmt = connection.prepareStatement(sql);
            paymentStmt.setBigDecimal(1, amount);
            paymentStmt.setDate(2, todayDate);
            paymentStmt.setTime(3, currentTime);
            paymentStmt.setString(4, bookingNum);

            paymentGenerated = paymentStmt.executeUpdate();

            if (paymentGenerated > 0) {
                System.out.println("Payment inserted successfully!");
            } else {
                System.out.println("Payment insertion failed.");
            }

        } catch (SQLException e) {
            System.err.println("Database error: " + e.getMessage());
        } finally {
            // Close resources in a finally block
            try {
                if (paymentStmt != null) {
                    paymentStmt.close();
                }
            } catch (SQLException e) {
                System.err.println("Error closing statement: " + e.getMessage());
            }
        }
    }
*/


  
     


    public static void closeConnection() {
        try {
            if (connection != null && !connection.isClosed()) {
                connection.close();
                System.out.println("Database connection closed.");
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }
}