/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package trainx_project;
import java.util.Date;

/**
 *
 * @author Imtinan Alhajri
 */

class Person {
    private String ID;
    private String Password;
    private String FirstName;
    private String LastName;
    
    private Date DOB ;

    public Person(String ID,String Password, String FirstName, String LastName, Date DOB) {
        this.ID = ID;
        this.FirstName = FirstName;
        this.LastName = LastName;
        this.Password = Password;
        this.DOB = DOB;
    }

    /**
     * @return the ID
     */
    public String getID() {
        return ID;
    }

    /**
     * @param ID the ID to set
     */
    public void setID(String ID) {
        this.ID = ID;
    }

    /**
     * @return the FirstName
     */
    public String getFirstName() {
        return FirstName;
    }

    /**
     * @param FirstName the FirstName to set
     */
    public void setFirstName(String FirstName) {
        this.FirstName = FirstName;
    }

    /**
     * @return the LastName
     */
    public String getLastName() {
        return LastName;
    }

    /**
     * @param LastName the LastName to set
     */
    public void setLastName(String LastName) {
        this.LastName = LastName;
    }

    /**
     * @return the Password
     */
    public String getPassword() {
        return Password;
    }

    /**
     * @param Password the Password to set
     */
    public void setPassword(String Password) {
        this.Password = Password;
    }

    /**
     * @return the DOB
     */
    public Date getDOB() {
        return DOB;
    }

    /**
     * @param DOB the DOB to set
     */
    public void setDOB(Date DOB) {
        this.DOB = DOB;
    }

    @Override
    public String toString() {
        return "Person{" + "ID=" + ID + ", Password=" + Password + ", FirstName=" + FirstName + ", LastName=" + LastName + ", DOB=" + DOB + '}';
    }
    
}
class Manager extends Person {
    String email;
    String phoneNumber;
    double salary;

    Manager(String ID, String Password ,String FirstName, String LastName,
            String email, String phoneNumber,Date DOB, double salary) {
        super(ID, Password,FirstName, LastName, DOB);
        this.email = email;
        this.phoneNumber = phoneNumber;
        this.salary = salary;
    }

    // Getters and Setters for Manager attributes
    public String getEmail() {
        return email;
    }

    public void setEmail(String email) {
        this.email = email;
    }

    public String getPhoneNumber() {
        return phoneNumber;
    }

    public void setPhoneNumber(String phoneNumber) {
        this.phoneNumber = phoneNumber;
    }

    public double getSalary() {
        return salary;
    }

    public void setSalary(double salary) {
        this.salary = salary;
    }

    @Override
    public String toString() {
        return super.toString()+  "Manager{" + "email=" + email + ", phoneNumber=" + phoneNumber + ", salary=" + salary + '}';
    }
    
}

        
    
    
    

