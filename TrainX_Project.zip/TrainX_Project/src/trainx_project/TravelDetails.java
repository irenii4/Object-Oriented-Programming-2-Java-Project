/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/GUIForms/JFrame.java to edit this template
 */
package trainx_project;

import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.Dimension;
import java.awt.GridLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Calendar;
import java.util.Date;
import java.util.HashSet;
import java.util.List;
import java.util.Set;
import javax.swing.BorderFactory;
import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JTable;
import trainx_project.ConfirmYourTripDetails;
import trainx_project.Schedules;
import trainx_project.TrainXDBCon;

/**
 *
 * @author hanji
 */
public class TravelDetails extends javax.swing.JFrame {
// *************************** LOOK HERE :) //***************************
    
    private List<String> allSeats = new ArrayList<>(Arrays.asList(
    "A1", "B1", "C1", "D1",
    "A2", "B2", "C2", "D2",
    "A3", "B3", "C3", "D3",
    "A4", "B4", "C4", "D4",
    "A5", "B5", "C5", "D5",
    "A6", "B6", "C6", "D6",
    "A7", "B7", "C7", "D7"
));

private final ArrayList<String> firstClass = new ArrayList<>(Arrays.asList(
    "A1", "B1", "C1", "D1",
    "A2", "B2", "C2", "D2"
));

private final ArrayList<String> economyClass = new ArrayList<>(Arrays.asList(
    "A3", "B3", "C3", "D3",
    "A4", "B4", "C4", "D4",
    "A5", "B5", "C5", "D5",
    "A6", "B6", "C6", "D6",
    "A7", "B7", "C7", "D7"
));


    public static ConfirmYourTripDetails cytdFrame;
    List<String> unavailableSeats;

    public static BigDecimal totalFee;
    
    TrainXDBCon dbCon;//connection 
    
    public static String PassId;
    
    boolean roundTrip=false;//retrive if RoundTrip or not

    public static String travelFromCity;
    public static String travelToCity;
    
    public static int goTrainId;
    public static int returnTrainId;
    
    public static Date travelDate;
    public static Date returnDate;
    
   ArrayList<String> choosenSeats;
   ArrayList<String> classOfSeats;
   ArrayList<Double> ticketsFee;
   
   Set<String> selectedSeats;
   
   ArrayList<Schedules> goScedules;
   ArrayList<Schedules> returnScedules;
   List<JButton> seatButtons;
   
   MultiSeatSelectionGUI seatSelection;
   
   boolean goToNextFrame;
   String trainRoute;
   // ********************************************************************
    
    
    /**
     * Creates new form TravelDetails
     */
    public static String passId;
    public TravelDetails(String passId) {//////////////////////////////////////////////////
        initComponents();
        this.passId=passId;
        // *************************** LOOK HERE :) ***************************
         unavailableSeats=new ArrayList<String>();
         classOfSeats=new ArrayList<String>();
         ticketsFee=new ArrayList<Double>();
         choosenSeats=new ArrayList<>();
         
         dbCon=new TrainXDBCon();
        
         //choosenSeats=new ArrayList<String>();;
        
        
        //unavailableSeats=dbCon.getSelectedSeats(pmtFrame.goTrainId,new java.sql.Date(pmtFrame.travelDate.getTime()));
        
        // ********************************************************************
        
            setTitle("Trip Details");
            
            
            seatSelection = new MultiSeatSelectionGUI();
            seatLayoutPanel.add(seatSelection);
            seatLayoutPanel.setVisible(false);
            SeatChoose.setVisible(false); 
            DateReturnChooser.setVisible(false);
            returndateLabel.setVisible(false);

            DatetravelChooser.getDateEditor().addPropertyChangeListener(evt -> {
                if ("date".equals(evt.getPropertyName())) {
                    Date selectedDate = (Date) evt.getNewValue();
                    if (selectedDate != null) {
                        checkDateValidity(selectedDate, true); // true يعني حقل الذهاب
                    }
                }
            });

            DateReturnChooser.getDateEditor().addPropertyChangeListener(evt -> {
                if ("date".equals(evt.getPropertyName())) {
                    Date selectedDate = (Date) evt.getNewValue();
                    if (selectedDate != null) {
                        Date departureDate = DatetravelChooser.getDate();
                        if (departureDate != null) {
                            checkDateValidity(selectedDate, false, departureDate);
                        } else {
                            JOptionPane.showMessageDialog(this, "Please select a departure date first!", "WARNING", JOptionPane.WARNING_MESSAGE);
                            DateReturnChooser.setDate(null);
                        }
                    }
                }
            });

            cityListFrom.addListSelectionListener(e -> {
                if (!e.getValueIsAdjusting()) {
                    String fromCity = cityListTo.getSelectedValue();
                    String toCity = cityListFrom.getSelectedValue();
                    if (fromCity != null && toCity != null && fromCity.equals(toCity)) {
                        JOptionPane.showMessageDialog(this, "You cannot select the same city! Please select a different city.", "WARNING", JOptionPane.WARNING_MESSAGE);
                        cityListTo.clearSelection();
                    }
                }
            });

            cityListTo.addListSelectionListener(e -> {
                if (!e.getValueIsAdjusting()) {
                    String fromCity = cityListTo.getSelectedValue();
                    String toCity = cityListFrom.getSelectedValue();
                    if (fromCity != null && toCity != null && fromCity.equals(toCity)) {
                        JOptionPane.showMessageDialog(this, "You cannot select the same city! Please select a different city.", "WARNING", JOptionPane.WARNING_MESSAGE);
                        cityListTo.clearSelection();
                    }
                }
            });
        } 

    /**
     * This method is called from within the constructor to initialize the form.
     * WARNING: Do NOT modify this code. The content of this method is always
     * regenerated by the Form Editor.
     */
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        buttonGroup1 = new javax.swing.ButtonGroup();
        jScrollPane1 = new javax.swing.JScrollPane();
        jTree1 = new javax.swing.JTree();
        jLabel1 = new javax.swing.JLabel();
        jPanel1 = new javax.swing.JPanel();
        jLabel2 = new javax.swing.JLabel();
        jLabel3 = new javax.swing.JLabel();
        jLabel4 = new javax.swing.JLabel();
        RoundTrip = new javax.swing.JRadioButton();
        returndateLabel = new javax.swing.JLabel();
        SingleTrack = new javax.swing.JRadioButton();
        jScrollPane2 = new javax.swing.JScrollPane();
        cityListTo = new javax.swing.JList<>();
        CancleButton = new javax.swing.JButton();
        searchButton = new javax.swing.JButton();
        jScrollPane3 = new javax.swing.JScrollPane();
        cityListFrom = new javax.swing.JList<>();
        DatetravelChooser = new com.toedter.calendar.JDateChooser();
        DateReturnChooser = new com.toedter.calendar.JDateChooser();
        seatLayoutPanel = new javax.swing.JPanel();
        SeatChoose = new javax.swing.JPanel();
        fistClassIcon = new javax.swing.JLabel();
        jLabel6 = new javax.swing.JLabel();
        jLabel7 = new javax.swing.JLabel();
        ecoClass = new javax.swing.JLabel();
        jLabel9 = new javax.swing.JLabel();
        jLabel10 = new javax.swing.JLabel();
        returnToMainPageButton = new javax.swing.JButton();
        ConfirmButton = new javax.swing.JButton();

        jScrollPane1.setViewportView(jTree1);

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);
        setBackground(new java.awt.Color(255, 255, 255));
        getContentPane().setLayout(null);

        jLabel1.setBackground(new java.awt.Color(255, 255, 255));
        jLabel1.setFont(new java.awt.Font("Times New Roman", 1, 30)); // NOI18N
        jLabel1.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        jLabel1.setText("Select Your Trip Details");
        jLabel1.setPreferredSize(new java.awt.Dimension(400, 33));
        getContentPane().add(jLabel1);
        jLabel1.setBounds(206, 41, 350, 30);

        jPanel1.setBackground(new java.awt.Color(255, 255, 255));

        jLabel2.setBackground(new java.awt.Color(255, 255, 255));
        jLabel2.setFont(new java.awt.Font("Times New Roman", 1, 14)); // NOI18N
        jLabel2.setText("Select your travel date :");

        jLabel3.setBackground(new java.awt.Color(255, 255, 255));
        jLabel3.setFont(new java.awt.Font("Times New Roman", 1, 14)); // NOI18N
        jLabel3.setText("From :");

        jLabel4.setBackground(new java.awt.Color(255, 255, 255));
        jLabel4.setFont(new java.awt.Font("Times New Roman", 1, 14)); // NOI18N
        jLabel4.setText("To:");

        RoundTrip.setBackground(new java.awt.Color(255, 255, 255));
        buttonGroup1.add(RoundTrip);
        RoundTrip.setFont(new java.awt.Font("Times New Roman", 1, 14)); // NOI18N
        RoundTrip.setText("RoundTrip");
        RoundTrip.setName("RoundTrip"); // NOI18N
        RoundTrip.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                RoundTripActionPerformed(evt);
            }
        });

        returndateLabel.setBackground(new java.awt.Color(255, 255, 255));
        returndateLabel.setFont(new java.awt.Font("Times New Roman", 1, 14)); // NOI18N
        returndateLabel.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        returndateLabel.setText("Return date: ");

        SingleTrack.setBackground(new java.awt.Color(255, 255, 255));
        buttonGroup1.add(SingleTrack);
        SingleTrack.setFont(new java.awt.Font("Times New Roman", 1, 14)); // NOI18N
        SingleTrack.setText("SingleTrack");
        SingleTrack.setName("RoundTrip"); // NOI18N
        SingleTrack.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                SingleTrackActionPerformed(evt);
            }
        });

        cityListTo.setFont(new java.awt.Font("Times New Roman", 1, 12)); // NOI18N
        cityListTo.setModel(new javax.swing.AbstractListModel<String>() {
            String[] strings = { "Riyadh", "Jeddah", "Medina", "Dammam", " " };
            public int getSize() { return strings.length; }
            public String getElementAt(int i) { return strings[i]; }
        });
        cityListTo.setSelectionMode(javax.swing.ListSelectionModel.SINGLE_SELECTION);
        jScrollPane2.setViewportView(cityListTo);

        CancleButton.setBackground(new java.awt.Color(255, 102, 102));
        CancleButton.setFont(new java.awt.Font("Times New Roman", 1, 14)); // NOI18N
        CancleButton.setText("Cancel");
        CancleButton.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                CancleButtonActionPerformed(evt);
            }
        });

        searchButton.setBackground(new java.awt.Color(204, 204, 204));
        searchButton.setFont(new java.awt.Font("Times New Roman", 1, 14)); // NOI18N
        searchButton.setText("Search");
        searchButton.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                searchButtonActionPerformed(evt);
            }
        });

        cityListFrom.setFont(new java.awt.Font("Times New Roman", 1, 12)); // NOI18N
        cityListFrom.setModel(new javax.swing.AbstractListModel<String>() {
            String[] strings = { "Riyadh", "Jeddah", "Medina", "Dammam", " " };
            public int getSize() { return strings.length; }
            public String getElementAt(int i) { return strings[i]; }
        });
        cityListFrom.setSelectionMode(javax.swing.ListSelectionModel.SINGLE_SELECTION);
        jScrollPane3.setViewportView(cityListFrom);

        DatetravelChooser.setBackground(new java.awt.Color(255, 255, 255));

        DateReturnChooser.setBackground(new java.awt.Color(255, 255, 255));

        javax.swing.GroupLayout jPanel1Layout = new javax.swing.GroupLayout(jPanel1);
        jPanel1.setLayout(jPanel1Layout);
        jPanel1Layout.setHorizontalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addGap(28, 28, 28)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                    .addComponent(jScrollPane3)
                    .addGroup(javax.swing.GroupLayout.Alignment.LEADING, jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING, false)
                        .addComponent(RoundTrip, javax.swing.GroupLayout.PREFERRED_SIZE, 95, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addComponent(jLabel2, javax.swing.GroupLayout.Alignment.LEADING, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                        .addComponent(jLabel3, javax.swing.GroupLayout.Alignment.LEADING, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                        .addComponent(returndateLabel, javax.swing.GroupLayout.Alignment.LEADING, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)))
                .addGap(23, 23, 23)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel1Layout.createSequentialGroup()
                        .addComponent(DatetravelChooser, javax.swing.GroupLayout.PREFERRED_SIZE, 141, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(0, 0, Short.MAX_VALUE))
                    .addGroup(jPanel1Layout.createSequentialGroup()
                        .addComponent(jLabel4, javax.swing.GroupLayout.PREFERRED_SIZE, 141, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                    .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel1Layout.createSequentialGroup()
                        .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                            .addComponent(DateReturnChooser, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                            .addGroup(jPanel1Layout.createSequentialGroup()
                                .addGap(0, 4, Short.MAX_VALUE)
                                .addComponent(jScrollPane2, javax.swing.GroupLayout.PREFERRED_SIZE, 141, javax.swing.GroupLayout.PREFERRED_SIZE)))
                        .addGap(57, 57, 57))))
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addGap(63, 63, 63)
                .addComponent(CancleButton, javax.swing.GroupLayout.PREFERRED_SIZE, 115, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(18, 18, 18)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(SingleTrack, javax.swing.GroupLayout.PREFERRED_SIZE, 106, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(searchButton, javax.swing.GroupLayout.PREFERRED_SIZE, 115, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );
        jPanel1Layout.setVerticalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addGap(26, 26, 26)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(jLabel2)
                    .addComponent(DatetravelChooser, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(18, 18, 18)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel3)
                    .addComponent(jLabel4))
                .addGap(18, 18, 18)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(jScrollPane2, javax.swing.GroupLayout.PREFERRED_SIZE, 102, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jScrollPane3, javax.swing.GroupLayout.PREFERRED_SIZE, 102, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(12, 12, 12)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(RoundTrip)
                    .addComponent(SingleTrack))
                .addGap(18, 18, 18)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(returndateLabel)
                    .addComponent(DateReturnChooser, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, 8, Short.MAX_VALUE)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(CancleButton)
                    .addComponent(searchButton))
                .addGap(20, 20, 20))
        );

        getContentPane().add(jPanel1);
        jPanel1.setBounds(345, 112, 401, 329);

        seatLayoutPanel.setBackground(new java.awt.Color(255, 255, 255));
        seatLayoutPanel.setToolTipText("Choose your Seat number");
        seatLayoutPanel.setLayout(new java.awt.GridLayout(1, 0));
        getContentPane().add(seatLayoutPanel);
        seatLayoutPanel.setBounds(42, 112, 285, 280);

        SeatChoose.setBackground(new java.awt.Color(255, 255, 255));

        fistClassIcon.setBackground(new java.awt.Color(255, 255, 255));
        fistClassIcon.setIcon(new javax.swing.ImageIcon(getClass().getResource("/trainx_project/firstClass2.png"))); // NOI18N
        fistClassIcon.setLabelFor(SeatChoose);
        fistClassIcon.setToolTipText("300sr");

        jLabel6.setBackground(new java.awt.Color(255, 255, 255));
        jLabel6.setFont(new java.awt.Font("Times New Roman", 1, 12)); // NOI18N
        jLabel6.setLabelFor(SeatChoose);
        jLabel6.setText("First");

        jLabel7.setBackground(new java.awt.Color(255, 255, 255));
        jLabel7.setFont(new java.awt.Font("Times New Roman", 1, 12)); // NOI18N
        jLabel7.setLabelFor(SeatChoose);
        jLabel7.setText("Economy");

        ecoClass.setIcon(new javax.swing.ImageIcon(getClass().getResource("/trainx_project/economeClass2.png"))); // NOI18N
        ecoClass.setLabelFor(SeatChoose);
        ecoClass.setToolTipText("150sr");

        jLabel9.setBackground(new java.awt.Color(255, 255, 255));
        jLabel9.setIcon(new javax.swing.ImageIcon(getClass().getResource("/trainx_project/choosen2.png"))); // NOI18N
        jLabel9.setLabelFor(SeatChoose);

        jLabel10.setBackground(new java.awt.Color(255, 255, 255));
        jLabel10.setFont(new java.awt.Font("Times New Roman", 1, 12)); // NOI18N
        jLabel10.setText("Selected Seat");
        jLabel10.setToolTipText("");

        javax.swing.GroupLayout SeatChooseLayout = new javax.swing.GroupLayout(SeatChoose);
        SeatChoose.setLayout(SeatChooseLayout);
        SeatChooseLayout.setHorizontalGroup(
            SeatChooseLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(SeatChooseLayout.createSequentialGroup()
                .addContainerGap()
                .addComponent(fistClassIcon)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(jLabel6, javax.swing.GroupLayout.PREFERRED_SIZE, 31, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addComponent(ecoClass)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(jLabel7)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(jLabel9)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(jLabel10)
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );
        SeatChooseLayout.setVerticalGroup(
            SeatChooseLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(SeatChooseLayout.createSequentialGroup()
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addGroup(SeatChooseLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, SeatChooseLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                        .addComponent(fistClassIcon)
                        .addGroup(SeatChooseLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                            .addComponent(ecoClass)
                            .addComponent(jLabel6)
                            .addComponent(jLabel9)
                            .addComponent(jLabel7)))
                    .addComponent(jLabel10, javax.swing.GroupLayout.Alignment.TRAILING)))
        );

        getContentPane().add(SeatChoose);
        SeatChoose.setBounds(42, 403, 290, 50);

        returnToMainPageButton.setFont(new java.awt.Font("Times New Roman", 1, 13)); // NOI18N
        returnToMainPageButton.setText("Return to User Main Page");
        returnToMainPageButton.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                returnToMainPageButtonActionPerformed(evt);
            }
        });
        getContentPane().add(returnToMainPageButton);
        returnToMainPageButton.setBounds(20, 40, 179, 30);

        ConfirmButton.setFont(new java.awt.Font("Times New Roman", 1, 13)); // NOI18N
        ConfirmButton.setText("Confirm");
        ConfirmButton.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                ConfirmButtonActionPerformed(evt);
            }
        });
        getContentPane().add(ConfirmButton);
        ConfirmButton.setBounds(560, 40, 180, 30);

        pack();
    }// </editor-fold>//GEN-END:initComponents
    
    private void checkDateValidity(Date selectedDate, boolean isDeparture) {
        Calendar today = Calendar.getInstance();
        today.setTime(new Date());
        Calendar selected = Calendar.getInstance();
        selected.setTime(selectedDate);

        if (selected.before(today) || selected.equals(today)) {
            JOptionPane.showMessageDialog(this, "Invalid date! Please select a future date.", "WARNING", JOptionPane.WARNING_MESSAGE);
            if (isDeparture) {
                DatetravelChooser.setDate(null);
            } else {
                DateReturnChooser.setDate(null);
            }
        }
    }

    private void checkDateValidity(Date selectedDate, boolean isDeparture, Date departureDate) {
        Calendar today = Calendar.getInstance();
        today.setTime(new Date());
        Calendar selected = Calendar.getInstance();
        selected.setTime(selectedDate);
        Calendar dep = Calendar.getInstance();
        dep.setTime(departureDate);

        if (selected.before(today) || selected.equals(today)) {
            JOptionPane.showMessageDialog(this, "Invalid date! Please select a future date.", "WARNING", JOptionPane.WARNING_MESSAGE);
            DateReturnChooser.setDate(null);
        } else if (selected.before(dep) || selected.equals(dep)) {
            JOptionPane.showMessageDialog(this, "Return date must be after departure date!", "WARNING", JOptionPane.WARNING_MESSAGE);
            DateReturnChooser.setDate(null); 
        }
    }
    
    private void RoundTripActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_RoundTripActionPerformed
        // TODO add your handling code here:
        if (RoundTrip.isSelected()) {
            DateReturnChooser.setEnabled(true);
            DateReturnChooser.setVisible(true);
            returndateLabel.setVisible(true);
        }
    }//GEN-LAST:event_RoundTripActionPerformed

    private void SingleTrackActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_SingleTrackActionPerformed
        // TODO add your handling code here:
        if (SingleTrack.isSelected()) {
            DateReturnChooser.setDate(null);
            DateReturnChooser.setEnabled(false);
            DateReturnChooser.setVisible(false);
            returndateLabel.setVisible(false);
        }
    }//GEN-LAST:event_SingleTrackActionPerformed

    private void searchButtonActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_searchButtonActionPerformed
        // TODO add your handling code here:
        // Validate departure date
        if (DatetravelChooser.getDate() == null) {
            JOptionPane.showMessageDialog(this, "Please select a departure date!", "Missing Information", JOptionPane.WARNING_MESSAGE);
            return;
        }

        // Validate from city
        if (cityListFrom.getSelectedValue() == null) {
            JOptionPane.showMessageDialog(this, "Please select a city to travel from!", "Missing Information", JOptionPane.WARNING_MESSAGE);
            return;
        }

        // Validate to city
        if (cityListTo.getSelectedValue() == null) {
            JOptionPane.showMessageDialog(this, "Please select a destination city!", "Missing Information", JOptionPane.WARNING_MESSAGE);
            return;
        }

        // Validate trip type (Radio Button selection)
        if (!RoundTrip.isSelected() && !SingleTrack.isSelected()) {
            JOptionPane.showMessageDialog(this, "Please select a trip type (Round Trip or Single Track)!", "Missing Information", JOptionPane.WARNING_MESSAGE);
            return;
        }
        
        // Validate seat selection
       /* MultiSeatSelectionGUI seatSelection = (MultiSeatSelectionGUI) seatLayoutPanel.getComponent(0);
        if (selectedSeats.isEmpty()) {//CHANGED : OLD "seatSelection.selectedSeats.isEmpty()"
            JOptionPane.showMessageDialog(this, "Please select at least one seat!", "Missing Information", JOptionPane.WARNING_MESSAGE);
            return;
        }*/

        // Validate return date if RoundTrip is selected
        if (RoundTrip.isSelected() && DateReturnChooser.getDate() == null) {
            JOptionPane.showMessageDialog(this, "Please select a return date for Round Trip!", "Missing Information", JOptionPane.WARNING_MESSAGE);
            return;
        }
        
            roundTrip= RoundTrip.isSelected();//for booking...
    
         
        travelDate = DatetravelChooser.getDate();
        travelFromCity = cityListFrom.getSelectedValue();
        travelToCity = cityListTo.getSelectedValue();
        trainRoute = RoundTrip.isSelected() ? "Round Trip" : "Single Track";
        
        returnDate=DateReturnChooser.getDate();
        
        
         goToNextFrame=doesSceduleExists();
        
            
        //}//end for loop
         
         /*if (goToNextFrame){
             if(choosenSeats.isEmpty()){
                 JOptionPane.showMessageDialog(this, "Please select at least one seat!", "Missing Information", JOptionPane.WARNING_MESSAGE);
                return;
             }else
                  cytdFrame = new ConfirmYourTripDetails(this,passId,trainRoute);
                  cytdFrame.setVisible(true);
                  this.dispose();
         }*/
        
        
        
        // *************************** LOOK HERE :) //***************************
        
     
 
        
   
        /* for (String seat : selectedSeats) {
            //chech the class and 
            if (isfirstClass(seat)) {
                classOfSeats.add("First Class");
                ticketsFee.add(250.0);
            } else if (isecoClass(seat)) {
                classOfSeats.add("Economy");
                ticketsFee.add(150.0);
            }

            //add seat number (for both trips)
            choosenSeats.add(seat);*/
            
        //}//end for loop
         
         // ********************************************************************
        
        /*String travelDate = DatetravelChooser.getDate().toString();
        String fromCity = cityListFrom.getSelectedValue();
        String toCity = cityListTo.getSelectedValue();
       
        String returnDate = (DateReturnChooser.getDate() != null) ? DateReturnChooser.getDate().toString() : " ";
        int totalPrice = seatSelection.calculateTotalPrice();*/
        
       
        //int totalPrice = seatSelection.calculateTotalPrice();
        
        //Set<String> selectedSeats = seatSelection.selectedSeats;
    
        //this.dispose();

        /*ConfirmYourTripDetails ConfirmYourTripDetailswindow = new ConfirmYourTripDetails(travelDate, travelFromCity, travelToCity,
                trainRoute, returnDate, totalPrice, selectedSeats,passId);
        ConfirmYourTripDetailswindow.setSize(800, 500);
        ConfirmYourTripDetailswindow.setVisible(true);*/
        
           
    }//GEN-LAST:event_searchButtonActionPerformed

    
    private void CancleButtonActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_CancleButtonActionPerformed
        // TODO add your handling code here:
        // here its should reteurn to the per windoe
        // complete hete
        enable();
    }//GEN-LAST:event_CancleButtonActionPerformed

    private void returnToMainPageButtonActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_returnToMainPageButtonActionPerformed
        // TODO add your handling code here:
        this.setVisible(false);
        PassMainPage pmpFrame= new PassMainPage(passId);
        pmpFrame.setSize(800,500);
        pmpFrame.setVisible(true);
        pmpFrame.setLocationRelativeTo(this);
        
    }//GEN-LAST:event_returnToMainPageButtonActionPerformed

    private void ConfirmButtonActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_ConfirmButtonActionPerformed
        // TODO add your handling code here:
        
        
        choosenSeats.clear();
        classOfSeats.clear();
        ticketsFee.clear();
        totalFee= BigDecimal.ZERO;
   
         for (String seat : selectedSeats) {
            //chech the class and 
            if (isfirstClass(seat)) {
                classOfSeats.add("First Class");
                ticketsFee.add(250.0);
                totalFee=totalFee.add(BigDecimal.valueOf(250.0));
            } else if (isecoClass(seat)) {
                classOfSeats.add("Economy");
                ticketsFee.add(150.0);
                totalFee=totalFee.add(BigDecimal.valueOf(150.0));
                
            }
            if (returnDate!=null){
                totalFee=totalFee.multiply(BigDecimal.TWO);
            }

            //add seat number (for both trips)
            choosenSeats.add(seat);
         }
         
         
        if (goToNextFrame){
             if(selectedSeats.isEmpty()){
                 JOptionPane.showMessageDialog(this, "Please select at least one seat!", "Missing Information", JOptionPane.WARNING_MESSAGE);
                return;
             }else
                 System.out.println(choosenSeats+"in travel date method");
                  cytdFrame = new ConfirmYourTripDetails(this,passId,trainRoute);
                  cytdFrame.setVisible(true);
                  cytdFrame.setLocationRelativeTo(this);
                  this.setVisible(false);
                  
         }
        
    }//GEN-LAST:event_ConfirmButtonActionPerformed
    
    
    
        boolean isfirstClass(String seat){
            return firstClass.contains(seat);
        }
        
        boolean isecoClass(String seat){
            return economyClass.contains(seat);
        }
    
        public boolean isunavailableSeats(String seat) {
            return unavailableSeats.contains(seat);
        }
        
        
        public boolean doesSceduleExists()
        {
            
            //get the scedules
             goScedules=dbCon.getTripsOneRoute(travelFromCity,travelToCity, new java.sql.Date(DatetravelChooser.getDate().getTime()));
             
             if (RoundTrip.isSelected()&&!SingleTrack.isSelected()) {
       
                returnScedules = dbCon.getTripsOneRoute(travelToCity, travelFromCity, new java.sql.Date(DateReturnChooser.getDate().getTime()));
            }
             
             
             // 1. round trip case
             if (RoundTrip.isSelected()){
                 if (goScedules.isEmpty()){
                     JOptionPane.showMessageDialog(this, "No trips available with the TRAVEL date", "No Trips Found", JOptionPane.WARNING_MESSAGE);
                     return false;
                 }
                 if (returnScedules.isEmpty()){
                     JOptionPane.showMessageDialog(this, "No trips available with the RETURN date", "No Trips Found", JOptionPane.WARNING_MESSAGE);
                     return false;
                 }
                 
               int result = JOptionPane.showConfirmDialog(
               null,
               "Trips found \nTravel Trips: "+goScedules.get(0)+"\nReturn trips: "+returnScedules.get(0),
               "Confirmation",
               JOptionPane.OK_CANCEL_OPTION,
               JOptionPane.QUESTION_MESSAGE);

            if (result == JOptionPane.OK_OPTION) {
                System.out.println("Confirmed.");// User clicked OK
                goTrainId=goScedules.get(0).getTrain_Id();
                returnTrainId=returnScedules.get(0).getTrain_Id();
           
                dbCon=new TrainXDBCon();
                unavailableSeats=dbCon.getSelectedSeats(goTrainId,new java.sql.Date(travelDate.getTime()));
        
                System.out.println(unavailableSeats+"in Pass modi");
                //unavailableSet = new HashSet<>(unavailableSeats);

                /*MultiSeatSelectionGUI seatSelection = new MultiSeatSelectionGUI();
                seatLayoutPanel.add(seatSelection);*/
                seatLayoutPanel.setVisible(true);
                SeatChoose.setVisible(true);
                disable();
                return true;
        
                } else {
                System.out.println("Cancelled."); // User clicked Cancel or closed the dialog
                return false;
            
                }
                
             }//end of round trip
             
             
             if(!RoundTrip.isSelected()&&SingleTrack.isSelected()){
                 
                if (goScedules.isEmpty()){
                     JOptionPane.showMessageDialog(this, "No trips available with the TRAVEL date", "No Trips Found", JOptionPane.WARNING_MESSAGE);
                     return false;
                }
             
                  
                 int result = JOptionPane.showConfirmDialog(
                 null,
                 "Trip found: "+goScedules.get(0),
                 "Confirmation",
                 JOptionPane.OK_CANCEL_OPTION,
                 JOptionPane.QUESTION_MESSAGE
                 );
               
               if (result == JOptionPane.OK_OPTION) {
                    System.out.println("Confirmed.");// User clicked OK
                    goTrainId=goScedules.get(0).getTrain_Id();
           
                    dbCon=new TrainXDBCon();
                    unavailableSeats=dbCon.getSelectedSeats(goTrainId,new java.sql.Date(travelDate.getTime()));
        
                    System.out.println(unavailableSeats+"in Pass modi");
        //unavailableSet = new HashSet<>(unavailableSeats);

        /*MultiSeatSelectionGUI seatSelection = new MultiSeatSelectionGUI();
        seatLayoutPanel.add(seatSelection);*/
        
        
                    disable();
                    return true;
        
           
                }else {
                    System.out.println("Cancelled."); // User clicked Cancel or closed the dialog
                    return false;
                }
             } 
            return false;
        }//eo doesSceduleExists
        
        public void disable(){
            //disable date chooser
            DatetravelChooser.setEnabled(false);
            DateReturnChooser.setEnabled(false);
            
            //disable Lists
            cityListFrom.setEnabled(false);
            cityListTo.setEnabled(false);
            
            //disable buttons
            RoundTrip.setEnabled(false);
            SingleTrack.setEnabled(false);
            
            seatLayoutPanel.setVisible(true);
            SeatChoose.setVisible(true); 
            seatSelection.repopulateSeats();
        
    }//eo disable
        
        public void enable(){
            //enable date chooser
            DatetravelChooser.setEnabled(true);
            DateReturnChooser.setEnabled(true);

            //enable Lists
            cityListFrom.setEnabled(true);
            cityListTo.setEnabled(true);

            //enable buttons
            RoundTrip.setEnabled(true);
            SingleTrack.setEnabled(true);
            
             seatLayoutPanel.setVisible(false);
             SeatChoose.setVisible(false); 
        }//eo enable
        
        
 
        
        

        
         // ********************************************************************
    public class MultiSeatSelectionGUI extends JPanel implements ActionListener {
        
        //private List<JButton> seatButtons;
        //Set<String> selectedSeats; //REMOVED FROM INNER CLASS 

        private final String[] allSeats = {
            "A1", "B1", "C1", "D1",
            "A2", "B2", "C2", "D2",
            "A3", "B3", "C3", "D3",
            "A4", "B4", "C4", "D4",
            "A5", "B5", "C5", "D5",
            "A6", "B6", "C6", "D6",
            "A7", "B7", "C7", "D7"
        };
        private final String[] firstClass = {
            "A1", "B1", "C1", "D1",
            "A2", "B2", "C2", "D2"
        };
        private final String[] ecoClass = {
            "A3", "B3", "C3", "D3",
            "A4", "B4", "C4", "D4",
            "A5", "B5", "C5", "D5",
            "A6", "B6", "C6", "D6",
            "A7", "B7", "C7", "D7"
        };
        //private final String[] unavailableSeats = {"B5", "C7","D1"};

        ImageIcon unavailableIcon = new ImageIcon(getClass().getResource("unVisible2.png"));
        ImageIcon firstClassIcon = new ImageIcon(getClass().getResource("firstClass2_1.png"));
        ImageIcon economyClassIcon = new ImageIcon(getClass().getResource("economeClass2_1.png"));
        ImageIcon ChooseSeatIcon = new ImageIcon(getClass().getResource("Choosen2.png"));
        
        public MultiSeatSelectionGUI() {
            System.out.println("\n\nMultiSeatSelectionGUI Constructor");
            setLayout(new GridLayout(7, 4, 5, 5));
            setBackground(new Color(255, 255, 255));

            selectedSeats = new HashSet<>();
            seatButtons = new ArrayList<>();

            for (String seat : allSeats) {
                System.out.println("\n\nAdding seats");
                JButton seatButton = new JButton();
                seatButton.setText(seat);
                seatButton.setPreferredSize(new Dimension(50, 50));
                seatButton.setFocusPainted(false);

                seatButton.setBorder(BorderFactory.createRaisedBevelBorder());
                seatButton.setForeground(Color.BLACK);

                if (isfirstClass(seat)) {
                    seatButton.setIcon(firstClassIcon);
                }
                if (isecoClass(seat)) {
                    seatButton.setIcon(economyClassIcon);
                }
                if (isunavailableSeats(seat)) {
                    seatButton.setEnabled(false);
                    seatButton.setIcon(unavailableIcon);
                } else {
                    seatButton.addActionListener(this);
                }

                add(seatButton);
                seatButtons.add(seatButton);
            }      
        }
        

        void repopulateSeats(){
            for(JButton b :seatButtons){
                if(unavailableSeats.contains(b.getText())){
                    b.setEnabled(false);
                    b.setIcon(unavailableIcon);
                }
            }
        }
       
        

        private void toggleSeatSelection(JButton button) {
            String seatNumber = button.getText();
            if (selectedSeats.contains(seatNumber)) {
                selectedSeats.remove(seatNumber);
                if (isfirstClass(seatNumber)) {
                    button.setIcon(firstClassIcon);
                    button.setBackground(new Color(180, 220, 255));
                } else if (isecoClass(seatNumber)) {
                    button.setIcon(economyClassIcon);
                    button.setBackground(new Color(200, 230, 255));
                }
                button.setForeground(Color.BLACK);
                button.setText(seatNumber);
            } else {
                selectedSeats.add(seatNumber);
                button.setIcon(ChooseSeatIcon);
                button.setBackground(Color.getHSBColor(180, 220, 225));
                button.setForeground(Color.BLACK);
                button.setText(seatNumber);
            }
        }
        
        
        
        @Override
        public void actionPerformed(ActionEvent e) {
            if (e.getSource() instanceof JButton) {
                JButton clickedButton = (JButton) e.getSource();
                if (seatButtons.contains(clickedButton) && clickedButton.isEnabled()) {
                    toggleSeatSelection(clickedButton);
                }
            }
        }

    }
               
    /**
     * @param args the command line arguments
     */
    
    public static void main(String args[]) {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(TravelDetails.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(TravelDetails.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(TravelDetails.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(TravelDetails.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>

          TravelDetails TravelDetailswindow = new TravelDetails(passId);
          TravelDetailswindow.setSize(800, 500);
          TravelDetailswindow.setVisible(true);
          

    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton CancleButton;
    private javax.swing.JButton ConfirmButton;
    private com.toedter.calendar.JDateChooser DateReturnChooser;
    private com.toedter.calendar.JDateChooser DatetravelChooser;
    private javax.swing.JRadioButton RoundTrip;
    private javax.swing.JPanel SeatChoose;
    private javax.swing.JRadioButton SingleTrack;
    private javax.swing.ButtonGroup buttonGroup1;
    private javax.swing.JList<String> cityListFrom;
    private javax.swing.JList<String> cityListTo;
    private javax.swing.JLabel ecoClass;
    private javax.swing.JLabel fistClassIcon;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel10;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JLabel jLabel3;
    private javax.swing.JLabel jLabel4;
    private javax.swing.JLabel jLabel6;
    private javax.swing.JLabel jLabel7;
    private javax.swing.JLabel jLabel9;
    private javax.swing.JPanel jPanel1;
    private javax.swing.JScrollPane jScrollPane1;
    private javax.swing.JScrollPane jScrollPane2;
    private javax.swing.JScrollPane jScrollPane3;
    private javax.swing.JTree jTree1;
    private javax.swing.JButton returnToMainPageButton;
    private javax.swing.JLabel returndateLabel;
    private javax.swing.JButton searchButton;
    private javax.swing.JPanel seatLayoutPanel;
    // End of variables declaration//GEN-END:variables
}
