package trainx_project;

import com.sun.jdi.connect.spi.Connection;
import java.awt.Color;

import java.sql.PreparedStatement;
import java.sql.SQLException;
import java.sql.*;
import java.sql.Date.*;
import java.util.ArrayList;
import java.util.Calendar;
import javax.swing.JOptionPane;


/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/GUIForms/JFrame.java to edit this template
 */

/**
 *
 * @author Imtinan Alhajri
 */
public class signup extends javax.swing.JFrame {

    /**
     * Creates new form 
     */
    
    public signup() {
        initComponents();

        jButton2.setText("Sign Up");
        jButton2.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                SignUpButtonActionPerformed(evt);
            }
        });

        setupListeners();
        addInputValidators(); // Initialize input validators
    }

    private void setupListeners() {
        // Tooltip for Password Field
        SignUpPasswordField.setToolTipText("Password must have at least 3 letters, 3 numbers, and only _ is allowed.");

        // Tooltip for First Name
        FirstNameTextField.setToolTipText("Enter your first name (letters only).");

        // Tooltip for Last Name
        LastNameTextField.setToolTipText("Enter your last name (letters only).");
    }

    private void SignUpButtonActionPerformed(java.awt.event.ActionEvent evt) {
        String firstName = FirstNameTextField.getText().trim();
        String lastName = LastNameTextField.getText().trim();
        String password = new String(SignUpPasswordField.getPassword()).trim();
        java.util.Date birthDate = BirthDateChooser.getDate();

        // Check if any field is empty
        if (firstName.isEmpty() || lastName.isEmpty() || password.isEmpty() || birthDate == null) {
            JOptionPane.showMessageDialog(this, "Please fill all fields.");
            return;
        }

        // First and Last name validation (only letters)
        if (!firstName.matches("[a-zA-Z]+")) {
            JOptionPane.showMessageDialog(this, "First name must contain only letters.");
            return;
        }

        if (!lastName.matches("[a-zA-Z]+")) {
            JOptionPane.showMessageDialog(this, "Last name must contain only letters.");
            return;
        }

        // Password validation: at least 3 letters, 3 numbers, and only _ allowed
        if (!isValidPassword(password)) {
            JOptionPane.showMessageDialog(this, "Password must have at least 3 letters, 3 numbers, and only _ is allowed.");
            return;
        }
        Calendar caly = Calendar.getInstance();
        caly.setTime(birthDate); // Go back 18 years
        int birthyear = caly.get(Calendar.YEAR);
        int minyear=1900;
        if (birthyear< minyear) {
            JOptionPane.showMessageDialog(this, "Please Select a valid birth year.");
            
            return;
        }

        // Birth Date validation: user must be 18+
        Calendar cal = Calendar.getInstance();
        cal.add(Calendar.YEAR, -18); // Go back 18 years
        
        java.util.Date eighteenYearsAgo = cal.getTime();
        if (birthDate.after(eighteenYearsAgo)) {
            JOptionPane.showMessageDialog(this, "You must be at least 18 years old to sign up.");
            return;
        }

        // If all validations pass, call isPassenger
        DBConnectionAndQueries con = new DBConnectionAndQueries();  // Create instance here
        ArrayList<Person> passengers = con.getAllPassengers(); // Get passengers from database
        java.sql.Date sqlBirthDate = new java.sql.Date(birthDate.getTime()); // Convert java.util.Date to java.sql.Date
        isPassenger(passengers, firstName, lastName, password, sqlBirthDate, con);  // Pass connection

    }
    // -- imtinan
    private void isPassenger(ArrayList<Person> pass, String firstName, String lastName, String password, java.sql.Date birthDate, DBConnectionAndQueries con) { //Added DBConnectionAndQueries con
        boolean foundMatch = false; // Flag to track if a matching passenger is found -- Imtinan
    System.out.println("entering is pass");
    System.out.println("pass.size(): " + pass.size());  // Check ArrayList size

    for (int i = 0; i < pass.size(); i++) {
        String passName = pass.get(i).getFirstName();
        String passLname = pass.get(i).getLastName();
        java.util.Date passDOB = pass.get(i).getDOB(); // Get the date of birth

        System.out.println("passName: " + passName);
        System.out.println("passLname: " + passLname);
        System.out.println("passDOB: " + passDOB);
        System.out.println("firstName: " + firstName);
        System.out.println("lastName: " + lastName);
        System.out.println("birthDate: " + birthDate);

        if (passDOB != null) {
            System.out.println("passDOB.getTime(): " + passDOB.getTime());
        } else {
            System.out.println("passDOB is null");
        }
        System.out.println("birthDate.getTime(): " + birthDate.getTime());

        if (passName.equalsIgnoreCase(firstName.trim())
                && passLname.equalsIgnoreCase(lastName.trim())){
                //&& (passDOB != null && passDOB.getTime() == birthDate.getTime())) { //Compare also the date of birth

            foundMatch = true; // Set the flag

            int choice = JOptionPane.showConfirmDialog(this, "You Already Have an Account, Do You Want to Sign in?", "Sign in Request", JOptionPane.YES_NO_OPTION);

            if (choice == JOptionPane.YES_OPTION) {
                UserLogin l = new UserLogin();
                l.setVisible(true);
                l.setLocationRelativeTo(this);
                l.setSize(800, 500);
                l.setResizable(false);
                this.dispose();

            }
            break; // Exit the loop since a match is found
        }
    }

    if (!foundMatch) {
        con.insertNewUser(firstName, lastName, password, birthDate, con); //Added con
    }
}

    private void addInputValidators() {
        // Password tooltip
        SignUpPasswordField.setToolTipText("Password must contain at least 3 letters, 3 numbers, and may only include underscore (_) as special character.");

        // Optional: Clear placeholder text on focus
        FirstNameTextField.addFocusListener(new java.awt.event.FocusAdapter() {
            public void focusGained(java.awt.event.FocusEvent evt) {
                if (FirstNameTextField.getText().equals("Fisrt Name")) {
                    FirstNameTextField.setText("");
                }
            }
        });

        LastNameTextField.addFocusListener(new java.awt.event.FocusAdapter() {
            public void focusGained(java.awt.event.FocusEvent evt) {
                if (LastNameTextField.getText().equals("Last Name")) {
                    LastNameTextField.setText("");
                }
            }
        });

        // Password validation (live while typing)
        SignUpPasswordField.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyReleased(java.awt.event.KeyEvent evt) {
                validatePassword();
            }
        });
    }

    private void validatePassword() {
        String password = new String(SignUpPasswordField.getPassword());
        if (isValidPassword(password)) {
            SignUpPasswordField.setForeground(Color.BLACK);
        } else {
            SignUpPasswordField.setForeground(Color.RED);
        }
    }

    private boolean isValidPassword(String password) {
        if (!password.matches("[a-zA-Z0-9_]+")) {
            return false; // Only letters, numbers, and underscore
        }

        int letterCount = 0, numberCount = 0;
        for (char c : password.toCharArray()) {
            if (Character.isLetter(c)) {
                letterCount++;
            } else if (Character.isDigit(c)) {
                numberCount++;
            }
        }
        return letterCount >= 3 && numberCount >= 3;
    }

    /**
     * This method is called from within the constructor to initialize the form.
     * WARNING: Do NOT modify this code. The content of this method is always
     * regenerated by the Form Editor.
     */
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jCalendar1 = new com.toedter.calendar.JCalendar();
        jPanel1 = new javax.swing.JPanel();
        jLabel1 = new javax.swing.JLabel();
        jLabel2 = new javax.swing.JLabel();
        FirstNameTextField = new javax.swing.JTextField();
        jLabel3 = new javax.swing.JLabel();
        LastNameTextField = new javax.swing.JTextField();
        jLabel4 = new javax.swing.JLabel();
        SignUpPasswordField = new javax.swing.JPasswordField();
        jLabel5 = new javax.swing.JLabel();
        jLabel6 = new javax.swing.JLabel();
        BirthDateChooser = new com.toedter.calendar.JDateChooser();
        jLabel8 = new javax.swing.JLabel();
        jButton2 = new javax.swing.JButton();
        BackButton = new javax.swing.JButton();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);
        setBackground(new java.awt.Color(51, 51, 51));
        setForeground(java.awt.Color.white);

        jPanel1.setBackground(new java.awt.Color(255, 255, 255));
        jPanel1.setForeground(new java.awt.Color(153, 153, 153));

        jLabel1.setFont(new java.awt.Font("Times New Roman", 1, 36)); // NOI18N
        jLabel1.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        jLabel1.setText("Sign Up");

        jLabel2.setFont(new java.awt.Font("Times New Roman", 1, 18)); // NOI18N
        jLabel2.setText("First Name");

        FirstNameTextField.setFont(new java.awt.Font("Times New Roman", 0, 12)); // NOI18N
        FirstNameTextField.setForeground(new java.awt.Color(153, 153, 153));
        FirstNameTextField.setText("Fisrt Name");

        jLabel3.setFont(new java.awt.Font("Times New Roman", 1, 18)); // NOI18N
        jLabel3.setText("Last Name");

        LastNameTextField.setFont(new java.awt.Font("Times New Roman", 0, 12)); // NOI18N
        LastNameTextField.setForeground(new java.awt.Color(153, 153, 153));
        LastNameTextField.setText("Last Name");

        jLabel4.setFont(new java.awt.Font("Times New Roman", 1, 18)); // NOI18N
        jLabel4.setText("Date of Birth");

        SignUpPasswordField.setFont(new java.awt.Font("Times New Roman", 0, 12)); // NOI18N
        SignUpPasswordField.setText("jPasswordField1");
        SignUpPasswordField.setToolTipText("Password must be at least 8 characters, include a number and a capital letter. ");
        SignUpPasswordField.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                SignUpPasswordFieldMouseClicked(evt);
            }
        });
        SignUpPasswordField.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                SignUpPasswordFieldActionPerformed(evt);
            }
        });

        jLabel5.setFont(new java.awt.Font("Times New Roman", 1, 18)); // NOI18N
        jLabel5.setText("Password");

        jLabel6.setFont(new java.awt.Font("Times New Roman", 3, 14)); // NOI18N
        jLabel6.setText("Already have an account?");

        BirthDateChooser.setBackground(new java.awt.Color(51, 51, 51));
        BirthDateChooser.setForeground(new java.awt.Color(153, 153, 153));

        jLabel8.setBackground(new java.awt.Color(255, 255, 255));

        jButton2.setBackground(new java.awt.Color(51, 51, 51));
        jButton2.setFont(new java.awt.Font("Times New Roman", 1, 14)); // NOI18N
        jButton2.setForeground(new java.awt.Color(204, 204, 204));
        jButton2.setText("Sign Up");
        jButton2.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton2ActionPerformed(evt);
            }
        });

        BackButton.setBackground(new java.awt.Color(51, 51, 51));
        BackButton.setFont(new java.awt.Font("Times New Roman", 1, 14)); // NOI18N
        BackButton.setForeground(new java.awt.Color(153, 153, 153));
        BackButton.setText("Back to Login Page");
        BackButton.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                BackButtonActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout jPanel1Layout = new javax.swing.GroupLayout(jPanel1);
        jPanel1.setLayout(jPanel1Layout);
        jPanel1Layout.setHorizontalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                        .addGroup(javax.swing.GroupLayout.Alignment.LEADING, jPanel1Layout.createSequentialGroup()
                            .addGap(417, 417, 417)
                            .addComponent(jLabel3)
                            .addGap(18, 18, 18)
                            .addComponent(LastNameTextField, javax.swing.GroupLayout.PREFERRED_SIZE, 160, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addGroup(jPanel1Layout.createSequentialGroup()
                            .addGap(412, 412, 412)
                            .addComponent(jLabel4)
                            .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                            .addComponent(BirthDateChooser, javax.swing.GroupLayout.PREFERRED_SIZE, 160, javax.swing.GroupLayout.PREFERRED_SIZE)))
                    .addGroup(jPanel1Layout.createSequentialGroup()
                        .addContainerGap()
                        .addComponent(jLabel8))
                    .addGroup(jPanel1Layout.createSequentialGroup()
                        .addGap(65, 65, 65)
                        .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                            .addGroup(jPanel1Layout.createSequentialGroup()
                                .addComponent(jLabel2)
                                .addGap(18, 18, 18)
                                .addComponent(FirstNameTextField, javax.swing.GroupLayout.PREFERRED_SIZE, 160, javax.swing.GroupLayout.PREFERRED_SIZE))
                            .addGroup(jPanel1Layout.createSequentialGroup()
                                .addComponent(jLabel5)
                                .addGap(18, 18, 18)
                                .addComponent(SignUpPasswordField, javax.swing.GroupLayout.PREFERRED_SIZE, 160, javax.swing.GroupLayout.PREFERRED_SIZE)))
                        .addComponent(jLabel1))
                    .addGroup(jPanel1Layout.createSequentialGroup()
                        .addGap(345, 345, 345)
                        .addComponent(jButton2))
                    .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel1Layout.createSequentialGroup()
                        .addContainerGap()
                        .addComponent(jLabel6)
                        .addGap(37, 37, 37)
                        .addComponent(BackButton, javax.swing.GroupLayout.PREFERRED_SIZE, 170, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(218, 218, 218)))
                .addContainerGap(115, Short.MAX_VALUE))
        );
        jPanel1Layout.setVerticalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addGap(22, 22, 22)
                .addComponent(jLabel1)
                .addGap(59, 59, 59)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                        .addComponent(FirstNameTextField, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addComponent(jLabel2))
                    .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                        .addComponent(jLabel3)
                        .addComponent(LastNameTextField, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)))
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel1Layout.createSequentialGroup()
                        .addGap(40, 40, 40)
                        .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(SignUpPasswordField, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(jLabel5)
                            .addComponent(jLabel4)))
                    .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel1Layout.createSequentialGroup()
                        .addGap(28, 28, 28)
                        .addComponent(BirthDateChooser, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)))
                .addGap(75, 75, 75)
                .addComponent(jButton2, javax.swing.GroupLayout.PREFERRED_SIZE, 31, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, 92, Short.MAX_VALUE)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel6)
                    .addComponent(BackButton))
                .addGap(38, 38, 38)
                .addComponent(jLabel8)
                .addGap(30, 30, 30))
        );

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jPanel1, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jPanel1, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents

    
   
    
    


    
    private void BackButtonActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_BackButtonActionPerformed
        // TODO add your handling code here:
        UserLogin uLoginPage = new UserLogin();
        uLoginPage.setVisible(true);
        uLoginPage.setLocationRelativeTo(this);
        uLoginPage.setResizable(false);
        uLoginPage.setSize(800,500);
        this.dispose();
    }//GEN-LAST:event_BackButtonActionPerformed

    private void jButton2ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton2ActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_jButton2ActionPerformed

    private void SignUpPasswordFieldMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_SignUpPasswordFieldMouseClicked
        // TODO add your handling code here:
        SignUpPasswordField.setText("");
    }//GEN-LAST:event_SignUpPasswordFieldMouseClicked

    private void SignUpPasswordFieldActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_SignUpPasswordFieldActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_SignUpPasswordFieldActionPerformed

    /**
     * @param args the command line arguments
     */
    public static void main(String args[]) {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(signup.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(signup.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(signup.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(signup.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>

        /* Create and display the form */
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new signup().setVisible(true);
            }
        });
    }
    
    
   




    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton BackButton;
    private com.toedter.calendar.JDateChooser BirthDateChooser;
    private javax.swing.JTextField FirstNameTextField;
    private javax.swing.JTextField LastNameTextField;
    private javax.swing.JPasswordField SignUpPasswordField;
    private javax.swing.JButton jButton2;
    private com.toedter.calendar.JCalendar jCalendar1;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JLabel jLabel3;
    private javax.swing.JLabel jLabel4;
    private javax.swing.JLabel jLabel5;
    private javax.swing.JLabel jLabel6;
    private javax.swing.JLabel jLabel8;
    private javax.swing.JPanel jPanel1;
    // End of variables declaration//GEN-END:variables
}
