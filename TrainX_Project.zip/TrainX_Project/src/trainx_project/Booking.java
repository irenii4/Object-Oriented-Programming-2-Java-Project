/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package trainx_project;

import java.time.LocalDate;
import java.util.Date;

/**
 *
 * @author Imtinan Alhajri
 */
public class Booking {
    private String bookingNumber;
    private Date bookingDate;
    private int numberOfPassengers;
    private String passengerId;
    private LocalDate bookingDate_;

    // Constructor
    public Booking(String bookingNumber, Date bookingDate, int numberOfPassengers, String passengerId) {
        this.bookingNumber = bookingNumber;
        this.bookingDate = bookingDate;
        this.numberOfPassengers = numberOfPassengers;
        this.passengerId = passengerId;
    }

    public Booking(LocalDate bookingDate_, int numberOfPassengers, String passengerId) {
        this.bookingDate_ = LocalDate.now();
        this.numberOfPassengers = numberOfPassengers;
        this.passengerId = passengerId;
    }

    

    // Getters
    public String getBookingNumber() {
        return bookingNumber;
    }

    public Date getBookingDate() {
        return bookingDate;
    }

    public int getNumberOfPassengers() {
        return numberOfPassengers;
    }

    public String getPassengerId() {
        return passengerId;
    }
    
}
