/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package trainx_project;

import java.util.Date;

/**
 *
 * @author Zahra Redha
 */
public class Tickets {
    
    private String Ticket_Id;
    private String Class_Type;  //ENUM('Economy', 'First Class') NOT NULL,
    private double Class_Price ;
    private String Seat_Number;
    private String Booking_Number;
    private int Train_Id;
    private Date travel_date;

    public Tickets(String Ticket_Id, String Class_Type, double Class_Price, String Seat_Number, String Booking_Number, int Train_Id, Date travel_date) {
        this.Ticket_Id = Ticket_Id;
        this.Class_Type = Class_Type;
        this.Class_Price = Class_Price;
        this.Seat_Number = Seat_Number;
        this.Booking_Number = Booking_Number;
        this.Train_Id = Train_Id;
        this.travel_date = travel_date;
    }

    @Override
    public String toString() {
        return "Tickets{" + "Ticket_Id=" + Ticket_Id + ", Class_Type=" + Class_Type + ", Class_Price=" + Class_Price + ", Seat_Number=" + Seat_Number + ", Booking_Number=" + Booking_Number + ", Train_Id=" + Train_Id + ", travel_date=" + travel_date + '}';
    }
    

    public String getTicket_Id() {
        return Ticket_Id;
    }

    public void setTicket_Id(String Ticket_Id) {
        this.Ticket_Id = Ticket_Id;
    }

    public String getClass_Type() {
        return Class_Type;
    }

    public void setClass_Type(String Class_Type) {
        this.Class_Type = Class_Type;
    }

    public double getClass_Price() {
        return Class_Price;
    }

    public void setClass_Price(double Class_Price) {
        this.Class_Price = Class_Price;
    }

    public String getSeat_Number() {
        return Seat_Number;
    }

    public void setSeat_Number(String Seat_Number) {
        this.Seat_Number = Seat_Number;
    }

    public String getBooking_Number() {
        return Booking_Number;
    }

    public void setBooking_Number(String Booking_Number) {
        this.Booking_Number = Booking_Number;
    }

    public int getTrain_Id() {
        return Train_Id;
    }

    public void setTrain_Id(int Train_Id) {
        this.Train_Id = Train_Id;
    }

    public Date getTravel_date() {
        return travel_date;
    }

    public void setTravel_date(Date travel_date) {
        this.travel_date = travel_date;
    }

    

    
    
    
}
